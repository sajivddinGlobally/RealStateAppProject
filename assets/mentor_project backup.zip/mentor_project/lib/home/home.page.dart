import 'dart:convert';
import 'dart:developer';
import 'package:educationapp/MyListing/MyListingPage.dart';
import 'package:educationapp/Profile/profileScreen.dart';
import 'package:educationapp/apiService.dart';
import 'package:educationapp/complete/complete.page.dart';
import 'package:educationapp/coreFolder/Controller/getRequestStudentController.dart';
import 'package:educationapp/coreFolder/Controller/myListingController.dart';
import 'package:educationapp/coreFolder/Controller/themeController.dart';
import 'package:educationapp/coreFolder/Controller/userProfileController.dart';
import 'package:educationapp/coreFolder/Model/sendRequestBodyModel.dart';
import 'package:educationapp/coreFolder/network/api.state.dart';
import 'package:educationapp/coreFolder/utils/preety.dio.dart';
import 'package:educationapp/home/CollegeDetail.dart';
import 'package:educationapp/home/CompanyDetail.dart';
import 'package:educationapp/home/MentorDetail.dart';
import 'package:educationapp/home/chatInbox.dart';
import 'package:educationapp/home/chating.page.dart';
import 'package:educationapp/home/findmentor.page.dart';
import 'package:educationapp/home/notification.page.dart';
import 'package:educationapp/home/onlineMentor.page.dart';
import 'package:educationapp/home/requestPage.dart';
import 'package:educationapp/home/settingProfile.page.dart';
import 'package:educationapp/home/trendingExprt.page.dart';
import 'package:educationapp/login/login.page.dart';
import 'package:educationapp/notificationService.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hive/hive.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import '../MyListing/CreateListPage.dart';
import '../wallet/wallet.page.dart';
import 'TendingSkill.dart';
import 'findAColllege.dart';
import 'findACompany.dart';
import '../coreFolder/Controller/homeDataController.dart';

class HomePage extends ConsumerStatefulWidget {
  int index;
  HomePage(this.index, {super.key});
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends ConsumerState<HomePage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  String filterQuery = "";
  int _currentIndex = 0; // Track the selected tab index
  @override
  void initState() {
    super.initState();
    _currentIndex = widget.index;
  }

  final List<Widget> _pages = [
    HomePageContent(), // Home page content (extracted below)
    Chatinbox(),
    MyListing(),
    ProfilePage(),
  ];
  String limitString(String text, int limit) {
    if (text.length <= limit) return text;
    return '${text.substring(0, limit)}..';
  }

  Future<bool> _onWillPop() async {
    if (_currentIndex > 0) {
      setState(() {
        _currentIndex = 0;
      });
      return false;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    final themeMode = ref.watch(themeProvider);
    var box = Hive.box('userdata');

    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        backgroundColor:
            themeMode == ThemeMode.dark ? Colors.white : Color(0xFF1B1B1B),
        key: _scaffoldKey,
        drawer: drawerWidget(box),
        body: IndexedStack(
          index: _currentIndex,
          children: _pages,
        ),
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: (index) {
            setState(() {
              _currentIndex = index;
            });
          },
          type: BottomNavigationBarType.fixed,
          backgroundColor: const Color(0xff008080),
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          selectedLabelStyle: GoogleFonts.roboto(fontSize: 12.sp),
          unselectedLabelStyle: GoogleFonts.roboto(fontSize: 12.sp),
          items: [
            BottomNavigationBarItem(
              icon: Icon(Icons.home, size: 24.sp),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.message_outlined, size: 24.sp),
              label: 'Chats',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.list, size: 24.sp),
              label: 'My Listings',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person, size: 24.sp),
              label: 'Profile',
            ),
          ],
        ),
      ),
    );
  }

  Widget drawerWidget(Box box) {
    final userType = box.get('userType');
    final asyncProfile = ref.watch(userProfileController);
    // 2. Hive StateProvider से डेटा पढ़ें (यह अपडेट होने पर UI को री-रेंडर करेगा)
    final profile = ref.watch(hiveProfileProvider);
    final themeMode = ref.watch(themeProvider);
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Container(
        height: MediaQuery.of(context).size.height,
        width: 280.w,
        decoration: BoxDecoration(
            // color: Colors.white,
            color:
                themeMode == ThemeMode.dark ? Colors.white : Color(0xFF1B1B1B),
            borderRadius: BorderRadius.circular(30.r)),
        child: Column(
          children: [
            Container(
              height: 250.h,
              width: 280.w,
              decoration: BoxDecoration(
                color: const Color(0xff008080),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(30.r),
                  topRight: Radius.circular(30.r),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  InkWell(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Container(
                      margin: EdgeInsets.only(left: 10.w, top: 20.h),
                      width: 40.w,
                      height: 40.h,
                      decoration: const BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                      ),
                      child: Center(
                        child: Padding(
                          padding: EdgeInsets.only(left: 8),
                          child: Icon(
                            Icons.arrow_back_ios,
                            size: 20,
                            color: themeMode == ThemeMode.dark
                                ? Color(0xFF1B1B1B)
                                : null,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding:
                        EdgeInsets.symmetric(horizontal: 10.w, vertical: 25.h),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          height: 50.w,
                          width: 50.w,
                          decoration: BoxDecoration(
                            color: const Color.fromARGB(25, 255, 255, 255),
                            borderRadius: BorderRadius.circular(500.r),
                          ),
                          child: ClipOval(
                            child: Image.network(
                              // profileImage['profile_picture']?.toString() ??
                              profile?['profile_picture'] ??
                                  "https://upload.wikimedia.org/wikipedia/commons/8/89/Portrait_Placeholder.png",
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) {
                                return ClipOval(
                                  child: Image.network(
                                    "https://upload.wikimedia.org/wikipedia/commons/8/89/Portrait_Placeholder.png",
                                    fit: BoxFit.cover,
                                  ),
                                );
                              },
                            ),
                          ),
                        ),
                        // InkWell(
                        //   onTap: () {
                        //     Navigator.push(
                        //         context,
                        //         CupertinoPageRoute(
                        //           builder: (context) =>
                        //               ProfileCompletionWidget(true),
                        //         ));
                        //   },
                        //   child: Container(
                        //     height: 38.h,
                        //     decoration: BoxDecoration(
                        //         color: const Color(0xFFA8E6CF),
                        //         borderRadius: BorderRadius.circular(40.r)),
                        //     child: Center(
                        //       child: Padding(
                        //         padding: EdgeInsets.symmetric(horizontal: 12.w),
                        //         child: Text(
                        //           "Edit Profile",
                        //           style: GoogleFonts.roboto(
                        //               color: const Color(0xFF1B1B1B),
                        //               fontSize: 12.sp),
                        //         ),
                        //       ),
                        //     ),
                        //   ),
                        // ),
                      ],
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.only(left: 20.w),
                        child: Text(
                          // profile['full_name'] ?? "User",
                          profile?['full_name'] ?? "User",
                          style: GoogleFonts.roboto(
                            fontSize: 18.sp,
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(left: 20.w),
                        child: Text(
                          "${box.get('email') ?? 'N/A'}",
                          style: GoogleFonts.roboto(
                            fontSize: 12.sp,
                            fontWeight: FontWeight.w400,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(height: 10.h),
            if (userType == "Student")
              ListTile(
                dense: true,
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const FindMentorPage(),
                      ));
                },
                leading: Image.asset(
                  "assets/drawer1.png",
                  color: themeMode == ThemeMode.light
                      ? Colors.white
                      : Color(0xff008080),
                ),
                title: Text(
                  "Find a Mentor",
                  style: GoogleFonts.roboto(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w600,
                    //color: const Color.fromARGB(255, 27, 27, 27),
                    color: themeMode == ThemeMode.light
                        ? Colors.white
                        : Color(0xFF1B1B1B),
                  ),
                ),
              ),
            if (userType == "Student")
              ListTile(
                dense: true,
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => FindSkillPage(),
                      ));
                },
                leading: Image.asset(
                  "assets/drawer2.png",
                  color: themeMode == ThemeMode.light
                      ? Colors.white
                      : Color(0xff008080),
                ),
                title: Text(
                  "Trending Skills",
                  style: GoogleFonts.roboto(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w600,
                    //color: const Color.fromARGB(255, 27, 27, 27),
                    color: themeMode == ThemeMode.light
                        ? Colors.white
                        : Color(0xFF1B1B1B),
                  ),
                ),
              ),
            if (userType == "Student")
              ListTile(
                dense: true,
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const FindCollegePage(),
                      ));
                },
                leading: Image.asset(
                  "assets/drawer3.png",
                  color: themeMode == ThemeMode.light
                      ? Colors.white
                      : Color(0xff008080),
                ),
                title: Text(
                  "Explore Colleges",
                  style: GoogleFonts.roboto(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w600,
                    // color: const Color.fromARGB(255, 27, 27, 27),
                    color: themeMode == ThemeMode.light
                        ? Colors.white
                        : Color(0xFF1B1B1B),
                  ),
                ),
              ),
            if (userType == "Student")
              ListTile(
                dense: true,
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const FindCompanyPage(),
                      ));
                },
                leading: Image.asset(
                  "assets/drawer4.png",
                  color: themeMode == ThemeMode.light
                      ? Colors.white
                      : Color(0xff008080),
                ),
                title: Text(
                  "Explore Companies",
                  style: GoogleFonts.roboto(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w600,
                    // color: const Color.fromARGB(255, 27, 27, 27),
                    color: themeMode == ThemeMode.light
                        ? Colors.white
                        : Color(0xFF1B1B1B),
                  ),
                ),
              ),

            // if (userType == "Student")
            //   ListTile(
            //     dense: true,
            //     onTap: () {
            //       Navigator.push(
            //           context,
            //           MaterialPageRoute(
            //             builder: (context) => const SavedList(),
            //           ));
            //     },
            //     leading: Image.asset(
            //       "assets/drawer3.png",
            //       color: themeMode == ThemeMode.light ? Colors.white : null,
            //     ),
            //     title: Text(
            //       "Saved List",
            //       style: GoogleFonts.roboto(
            //         fontSize: 16.sp,
            //         fontWeight: FontWeight.w600,
            //         // color: const Color.fromARGB(255, 27, 27, 27),
            //         color: themeMode == ThemeMode.light
            //             ? Colors.white
            //             : Color(0xFF1B1B1B),
            //       ),
            //     ),
            //   ),

            if (userType == "Student")
              ListTile(
                dense: true,
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => CreateListPage(),
                      ));
                },
                leading: Image.asset(
                  "assets/list.png",
                  color: themeMode == ThemeMode.light
                      ? Colors.white
                      : Color(0xff008080),
                ),
                title: Text(
                  "Create New List",
                  style: GoogleFonts.roboto(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w600,
                    // color: const Color.fromARGB(255, 27, 27, 27),
                    color: themeMode == ThemeMode.light
                        ? Colors.white
                        : Color(0xFF1B1B1B),
                  ),
                ),
              ),

            if (userType == "Professional" || userType == "Mentor")
              ListTile(
                dense: true,
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => WalletPage(),
                      ));
                },
                leading: Image.asset(
                  "assets/drawer5.png",
                  color: themeMode == ThemeMode.light
                      ? Colors.white
                      : Color(0xff008080),
                ),
                title: Text(
                  "Wallet",
                  style: GoogleFonts.roboto(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w600,
                    // color: const Color.fromARGB(255, 27, 27, 27),
                    color: themeMode == ThemeMode.light
                        ? Colors.white
                        : Color(0xFF1B1B1B),
                  ),
                ),
              ),
            ListTile(
              dense: true,
              onTap: () {
                Fluttertoast.showToast(
                    msg: themeMode == ThemeMode.light
                        ? "Light Mode On"
                        : "Dark Mode On");
                ref.read(themeProvider.notifier).toggleTheme();
              },
              leading: Image.asset(
                "assets/drawer6.png",
                color: themeMode == ThemeMode.light
                    ? Colors.white
                    : Color(0xff008080),
              ),
              title: Text(
                themeMode == ThemeMode.light ? "Light Mode" : "Dark Mode",
                style: GoogleFonts.roboto(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w600,
                  // color: const Color.fromARGB(255, 27, 27, 27),
                  color: themeMode == ThemeMode.light
                      ? Colors.white
                      : Color(0xFF1B1B1B),
                ),
              ),
            ),
            ListTile(
              dense: true,
              onTap: () {
                Navigator.push(
                    context,
                    CupertinoPageRoute(
                      builder: (context) => SettingProfilePage(),
                    ));
              },
              leading: Image.asset(
                "assets/drawer7.png",
                color: themeMode == ThemeMode.light
                    ? Colors.white
                    : Color(0xff008080),
              ),
              title: Text(
                "Settings",
                style: GoogleFonts.roboto(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w600,
                  //  color: const Color.fromARGB(255, 27, 27, 27),
                  color: themeMode == ThemeMode.light
                      ? Colors.white
                      : Color(0xFF1B1B1B),
                ),
              ),
            ),
            ListTile(
              dense: true,
              leading: Image.asset(
                "assets/insta.png",
                // width: 35.w,
                // height: 35.h,
                color: themeMode == ThemeMode.light
                    ? Colors.white
                    : Color(0xff008080),
              ),
              title: Text(
                "Instagram",
                style: GoogleFonts.roboto(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w600,
                  //  color: const Color.fromARGB(255, 27, 27, 27),
                  color: themeMode == ThemeMode.light
                      ? Colors.white
                      : Color(0xFF1B1B1B),
                ),
              ),
              onTap: () async {
                final url =
                    "https://www.instagram.com/educat.in?igsh=MWd4aHF3bThiMnJnZg==";
                await launchUrl(
                  Uri.parse(url),
                  // mode: LaunchMode.externalApplication,
                );
              },
            ),
            const Divider(),
            ListTile(
              dense: true,
              leading: Image.asset(
                "assets/logoutIcon.png",
                color: themeMode == ThemeMode.light
                    ? Colors.white
                    : Color(0xff008080),
              ),
              title: Text(
                "Logout",
                style: GoogleFonts.roboto(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w600,
                  //color: const Color.fromARGB(255, 27, 27, 27),
                  color: themeMode == ThemeMode.light
                      ? Colors.white
                      : Color(0xFF1B1B1B),
                ),
              ),
              onTap: () async {
                box.clear();
                log("Clearing data...");
                Navigator.pushAndRemoveUntil(
                    context,
                    CupertinoPageRoute(builder: (context) => const LoginPage()),
                    (route) => false);
                Fluttertoast.showToast(msg: "Logout Successfully");
              },
            ),
          ],
        ),
      ),
    );
  }
}

// Extracted HomePage content into a separate widget
class HomePageContent extends ConsumerStatefulWidget {
  const HomePageContent({super.key});
  @override
  _HomePageContentState createState() => _HomePageContentState();
}

class _HomePageContentState extends ConsumerState<HomePageContent> {
  String filterQuery = "";
  String limitString(String text, int limit) {
    if (text.length <= limit) return text;
    return '${text.substring(0, limit)}..';
  }

  bool isAccept = false;
  String? requestLenght;
  late WebSocketChannel channel;
  late int userId;
  String status = 'Connecting...';
  String statusMemtnro = 'ConnectingMentor...';
  int onlineMentorCount = 0;
  List<Map<String, dynamic>> onlineMentors =
      []; // mentor list store karne ke liye
  String? fcmToken;
  final api = ApiService();

  @override
  void initState() {
    super.initState();
    var box = Hive.box("userdata");
    userId = box.get("userid");
    _connectWebSocket();
    _connectedUsersCount();
    NotificationService.init();
    _loadToken();
  }

  Future<void> _loadToken() async {
    fcmToken = await NotificationService.getToken();
    setState(() {});
  }

  void _connectWebSocket() {
    try {
      final url =
          'wss://websocket.educatservicesindia.com/chat/ws/user/$userId';

      channel = WebSocketChannel.connect(Uri.parse(url));

      // 🔹 Connected message
      log('WebSocket connected successfully');
      setState(() {
        status = 'Connected successfully';
      });

      channel.stream.listen(
        (message) {
          // 🔹 Message received
          log('WebSocket message: $message');
        },
        onError: (error) {
          // 🔴 Error case
          log('WebSocket error: $error');
          setState(() {
            status = 'Connection error';
          });
        },
        onDone: () {
          // 🔴 Disconnected case
          log('WebSocket disconnected');
          setState(() {
            status = 'Disconnected from server';
          });

          // 🔁 Auto reconnect (optional)
          Future.delayed(const Duration(seconds: 3), () {
            log('Reconnecting WebSocket...');
            _connectWebSocket();
          });
        },
        cancelOnError: true,
      );
    } catch (e) {
      log('WebSocket connection failed: $e');
      setState(() {
        status = 'Connection failed';
      });
    }
  }

  /* void _connectWebSocket() {
    try {
      final url =
          'wss://websocket.educatservicesindia.com/chat/ws/user/${userId}';

      channel = WebSocketChannel.connect(Uri.parse(url));

      setState(() {
        status = 'Connected';
      });

      // Incoming messages listen karo
      channel.stream.listen(
        (message) {
          // log('Received: $message');
          // Yahan message handle karo (JSON parse etc.)
        },
        onError: (error) {
          log('WebSocket error: $error');
          setState(() {
            status = 'Error: $error';
          });
        },
        onDone: () {
          log('WebSocket closed: ${channel.closeReason}');
          setState(() {
            status = 'Disconnected';
          });
          // Optional: reconnect logic
          Future.delayed(const Duration(seconds: 3), _connectWebSocket);
        },
      );
    } catch (e) {
      setState(() {
        status = 'Connection failed: $e';
      });
    }
  }*/
  void _connectedUsersCount() {
    try {
      final url =
          'wss://websocket.educatservicesindia.com/chat/ws/presence/connected-users';
      channel = WebSocketChannel.connect(Uri.parse(url));
      setState(() {
        statusMemtnro = 'ConnectedMentor';
      });
      // Incoming messages listen karo
      channel.stream.listen(
        (message) {
          log('connectedUsersCount Received :$message');
          // Yahan message handle karo (JSON parse etc.)
          try {
            final data = jsonDecode(message) as Map<String, dynamic>;

            // Sirf "connected_users" type ke messages process karo
            if (data['type'] == 'connected_users') {
              final int count = data['count'] ?? 0;
              final List<dynamic> usersList = data['users'] ?? [];

              setState(() {
                onlineMentorCount = count;
                onlineMentors = usersList
                    .map((user) => user as Map<String, dynamic>)
                    .toList();
              });

              log('Updated Online Mentors: $count');
            }
            // Agar future mein aur types aayein (jaise single user online/offline), to yahan handle kar sakte ho
          } catch (e) {
            print('JSON Parse Error in Presence: $e');
          }
        },
        onError: (error) {
          log('WebSocket error: $error');
          setState(() {
            statusMemtnro = 'Error: $error';
          });
        },
        onDone: () {
          log('WebSocket closed: ${channel.closeReason}');
          setState(() {
            statusMemtnro = 'DisconnectedMentor';
          });
          // Optional: reconnect logic
          Future.delayed(const Duration(seconds: 3), _connectedUsersCount);
        },
      );
    } catch (e) {
      setState(() {
        statusMemtnro = 'Connection failed: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final themeMode = ref.watch(themeProvider);
    // Proper colors for dark/light mode
    final bool isDark = themeMode == ThemeMode.dark;
    final Color textColor = isDark ? Colors.black87 : Colors.white;
    final Color borderColor = isDark ? Color(0xff008080) : Color(0xff008080);
    final Color cardBackground = isDark ? Colors.black54 : Colors.white;
    final Color newCard = isDark ? Color(0xFFF2F0EF)! : Colors.black;

    var box = Hive.box('userdata');
    // final themeMode = ref.watch(themeProvider);
    final asyncProfile = ref.watch(userProfileController);
    final profile = ref.watch(hiveProfileProvider);
    final getHomeStudentData = ref.watch(getHomeStudentDataProvider);
    final getHomeMentorData = ref.watch(getHomeMentorDataProvider);
    final getRequestHomeData = ref.watch(getRequestStudentController);
    final userType = box.get('userType');
    final profileCompletion = box.get('profileCompletion')?.toDouble() ?? 0.45;
    final isLoading = getHomeStudentData.isLoading;
    if (isLoading) {
      return Center(
        child: CircularProgressIndicator(
          color: Colors.white,
        ),
      );
    }
    if (getHomeMentorData.hasError || getHomeStudentData.hasError) {
      final errorMessage = getHomeMentorData.error?.toString() ??
          getHomeStudentData.error?.toString() ??
          "Something went wrong";
      return Scaffold(
        backgroundColor:
            themeMode == ThemeMode.dark ? Colors.white : Color(0xFF1B1B1B),
        body: Center(
          child: Text(
            errorMessage,
            style: GoogleFonts.inter(fontSize: 20.sp, color: Colors.red),
            textAlign: TextAlign.center,
          ),
        ),
      );
    }
    return Scaffold(
      backgroundColor:
          themeMode == ThemeMode.dark ? Colors.white : Color(0xFF1B1B1B),
      body: RefreshIndicator(
        backgroundColor:
            themeMode == ThemeMode.dark ? Colors.white : Color(0xFF1B1B1B),
        color: themeMode == ThemeMode.dark ? Color(0xFF1B1B1B) : Colors.white,
        onRefresh: () async {
          _connectWebSocket();
          _connectedUsersCount();
          ref.invalidate(getRequestStudentController);
          ref.invalidate(getHomeStudentDataProvider);
          ref.invalidate(getHomeMentorDataProvider);
        },
        child: SafeArea(
          child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 20.h),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(width: 20.w),
                    GestureDetector(
                      onTap: () {
                        Scaffold.of(context).openDrawer();
                      },
                      child: Container(
                        height: 50.w,
                        width: 50.w,
                        decoration: BoxDecoration(
                            color: Color(0xff008080),
                            borderRadius: BorderRadius.circular(500.r)),
                        child: Center(
                          child: Icon(
                            Icons.dashboard_outlined,
                            color:
                                // themeMode == ThemeMode.dark
                                //     ?
                                // Color(0xff008080),
                                //     :
                                Colors.white,
                            size: 18.w,
                          ),
                        ),
                      ),
                    ),
                    const Spacer(),
                    SizedBox(
                      width: 30.w,
                    ),
                    Center(
                      child: Image.asset(
                        "assets/mentorLogo.png",
                        width: 100.w,
                        // color: themeMode == ThemeMode.dark
                        //     ? null
                        //     : Colors.white
                      ),
                    ),
                    const Spacer(),
                    IconButton(
                        onPressed: () {
                          // setState(() {
                          //   _HomePageState()._currentIndex =
                          //       4; // Navigate to Chat
                          // });
                          Navigator.push(
                              context,
                              CupertinoPageRoute(
                                builder: (context) => NotificationPage(),
                              ));
                        },
                        icon: Icon(
                          Icons.notifications_active_outlined,
                          color: Color(0xff008080),
                          size: 19.w,
                        )),
                    SizedBox(width: 3.w),
                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                            context,
                            CupertinoPageRoute(
                                builder: (context) => HomePage(3)));
                      },
                      child: Container(
                        height: 50.w,
                        width: 50.w,
                        decoration: BoxDecoration(
                          border: Border.all(
                            width: 2.0,
                            color: Color(0xff008080),
                          ),
                          color: const Color.fromARGB(25, 255, 255, 255),
                          borderRadius: BorderRadius.circular(500.r),
                        ),
                        child: ClipOval(
                          child: Image.network(
                            // profileImage['profile_picture']?.toString() ??
                            profile?['profile_picture'] ??
                                "https://upload.wikimedia.org/wikipedia/commons/8/89/Portrait_Placeholder.png",
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) {
                              return ClipOval(
                                child: Image.network(
                                  "https://upload.wikimedia.org/wikipedia/commons/8/89/Portrait_Placeholder.png",
                                  fit: BoxFit.cover,
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                    ),
                    SizedBox(width: 20.w),
                  ],
                ),
                SizedBox(height: 25.h),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20.w),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Text('WebSocket Status: $status'),
                          // Text('WebSocket Mentor: $statusMemtnro'),

                          Row(
                            children: [
                              Text(
                                "Welcome, ",
                                style: GoogleFonts.roboto(
                                  fontSize: 24.sp,
                                  fontWeight: FontWeight.w600,
                                  color: Color(0xff008080),
                                ),
                              ),
                              Text(
                                // profile['full_name'] ?? "User",
                                profile?['full_name'] ?? "User",
                                style: GoogleFonts.roboto(
                                    fontSize: 24.sp,
                                    fontWeight: FontWeight.w600,
                                    color: const Color(0xffA8E6CF)),
                              ),
                            ],
                          ),

                          Text(
                            "Let’s plan your bright future.",
                            style: GoogleFonts.roboto(
                                fontSize: 14.sp,
                                fontWeight: FontWeight.w400,
                                color: themeMode == ThemeMode.dark
                                    ? Color(0xFF1B1B1B)
                                    : Colors.white),
                          ),
                        ],
                      ),
                      const Spacer(),
                    ],
                  ),
                ),
                SizedBox(height: 30.h),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20.w),
                  child: Row(
                    children: [
                      if (userType == "Student")
                        Expanded(
                          child: InkWell(
                            onTap: () {
                              Navigator.push(
                                  context,
                                  CupertinoPageRoute(
                                    builder: (context) => OnlineMentorPage(
                                      onlineMentors: onlineMentors,
                                    ),
                                  ));
                            },
                            child: Container(
                              height: 130.h,
                              decoration: BoxDecoration(
                                //  color: const Color(0xff008080),
                                // color: themeMode == ThemeMode.dark
                                //     ?
                                color: Color(0xff008080),

                                // : Color(0xFF1B1B1B),
                                borderRadius: BorderRadius.circular(20.r),
                              ),
                              child: SingleChildScrollView(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    SizedBox(height: 15.h),
                                    Padding(
                                      padding: EdgeInsets.only(left: 15.w),
                                      child: Container(
                                        width: 50.w,
                                        height: 50.h,
                                        decoration: BoxDecoration(
                                          color:
                                              const Color.fromARGB(255, 0, 0, 0)
                                                  .withOpacity(0.1),
                                          shape: BoxShape.circle,
                                        ),
                                        child: Image.asset(
                                          "assets/mask1.png",
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                    SizedBox(height: 10.h),
                                    Padding(
                                      padding: EdgeInsets.only(left: 15.w),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "Mentors Online",
                                            style: GoogleFonts.roboto(
                                                fontSize: 11.sp,
                                                fontWeight: FontWeight.w400,
                                                color: Colors.white),
                                          ),
                                          Text(
                                            "$onlineMentorCount",
                                            style: GoogleFonts.roboto(
                                                fontSize: 11.sp,
                                                fontWeight: FontWeight.w400,
                                                color: Colors.white),
                                          ),

                                          // getHomeStudentData.when(
                                          //   data: (data) => Text(
                                          //     "${data.mentors?.values.fold(0, (sum, list) => sum + list.length) ?? 0}",
                                          //     style: GoogleFonts.roboto(
                                          //         fontSize: 16.sp,
                                          //         fontWeight: FontWeight.w600,
                                          //         color: Colors.white),
                                          //   ),
                                          //   loading: () => SizedBox(
                                          //     width: 20.w,
                                          //     height: 20.h,
                                          //     child:
                                          //         const CircularProgressIndicator(
                                          //             color: Colors.white,
                                          //             strokeWidth: 2),
                                          //   ),
                                          //   error: (error, stack) => Text(
                                          //     "N/A",
                                          //     style: GoogleFonts.roboto(
                                          //         fontSize: 16.sp,
                                          //         fontWeight: FontWeight.w600,
                                          //         color: Colors.white),
                                          //   ),
                                          // ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      SizedBox(width: 15.w),
                      if (userType == "Professional" || userType == "Mentor")
                        InkWell(
                          onTap: () {
                            Navigator.push(
                                context,
                                CupertinoPageRoute(
                                  builder: (context) => RequestPage(),
                                ));
                          },
                          child: Container(
                            height: 130.h,
                            width: 150.w,
                            decoration: BoxDecoration(
                              color: const Color(0xff008080),
                              borderRadius: BorderRadius.circular(20.r),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                SizedBox(height: 15.h),
                                Padding(
                                  padding: EdgeInsets.only(left: 15.w),
                                  child: Container(
                                    width: 50.w,
                                    height: 50.h,
                                    decoration: BoxDecoration(
                                      color: const Color.fromARGB(255, 0, 0, 0)
                                          .withOpacity(0.1),
                                      shape: BoxShape.circle,
                                    ),
                                    child: Image.asset(
                                      "assets/mask1.png",
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                                SizedBox(height: 10.h),
                                Padding(
                                  padding: EdgeInsets.only(left: 15.w),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "New Requests",
                                        style: GoogleFonts.roboto(
                                            fontSize: 11.sp,
                                            fontWeight: FontWeight.w400,
                                            color: Colors.white),
                                      ),
                                      Text(
                                        // "20",
                                        requestLenght ?? "0",
                                        style: GoogleFonts.roboto(
                                            fontSize: 16.sp,
                                            fontWeight: FontWeight.w600,
                                            color: Color(0xFF1B1B1B)),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      SizedBox(width: 15.w),
                      if (userType == "Student")
                        InkWell(
                          onTap: () {
                            Navigator.push(
                                context,
                                CupertinoPageRoute(
                                  builder: (context) => FindSkillPage(),
                                ));
                          },
                          child: Container(
                            height: 130.h,
                            width: 200.w,
                            decoration: BoxDecoration(
                              color: Color(0xff008080),
                              // color: const Color.fromARGB(255, 38, 38, 38),
                              borderRadius: BorderRadius.circular(20.r),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                SizedBox(height: 15.h),
                                Padding(
                                  padding: EdgeInsets.only(left: 15.w),
                                  child: Container(
                                    width: 50.w,
                                    height: 50.h,
                                    decoration: BoxDecoration(
                                      color: const Color.fromARGB(255, 0, 0, 0)
                                          .withOpacity(0.1),
                                      shape: BoxShape.circle,
                                    ),
                                    child: Image.asset(
                                      "assets/mask1.png",
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                                SizedBox(height: 10.h),
                                Padding(
                                  padding: EdgeInsets.only(left: 15.w),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "Skills Available",
                                        style: GoogleFonts.roboto(
                                            fontSize: 11.sp,
                                            fontWeight: FontWeight.w400,
                                            color: Colors.white),
                                      ),
                                      getHomeStudentData.when(
                                        data: (data) => Text(
                                          "${data.skills?.length ?? 0}",
                                          style: GoogleFonts.roboto(
                                              fontSize: 16.sp,
                                              fontWeight: FontWeight.w600,
                                              color: Colors.white),
                                        ),
                                        loading: () => SizedBox(
                                          width: 20.w,
                                          height: 20.h,
                                          child:
                                              const CircularProgressIndicator(
                                                  color: Colors.white,
                                                  strokeWidth: 2),
                                        ),
                                        error: (error, stack) => Text(
                                          "N/A",
                                          style: GoogleFonts.roboto(
                                              fontSize: 16.sp,
                                              fontWeight: FontWeight.w600,
                                              color: Colors.white),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                SizedBox(height: 20.h),
                // userType != "Professional"
                //     ?
                if (userType == "Professional" || userType == "Mentor")
                  Container(
                    // height: 500.h,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      // color: Colors.white,
                      color: themeMode == ThemeMode.dark
                          ? Colors.white
                          : Color(0xFF1B1B1B),

                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(20),
                        topRight: Radius.circular(20),
                      ),
                    ),
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          SizedBox(height: 20.h),
                          getHomeMentorData.when(
                            data: (mentorData) {
                              return Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  InkWell(
                                    onTap: () {
                                      Navigator.push(
                                          context,
                                          CupertinoPageRoute(
                                            builder: (context) =>
                                                ProfileCompletionWidget(true),
                                          ));
                                    },
                                    child: Container(
                                      margin: EdgeInsets.only(
                                          left: 20.w, right: 20.w),
                                      // width: 400.w.clamp(0, 400.w),
                                      padding:
                                          EdgeInsets.symmetric(vertical: 20.h),
                                      decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(30.r),
                                        color: themeMode == ThemeMode.dark
                                            ? Color.fromARGB(38, 0, 128, 128)
                                            : Color(0xFF008080),
                                      ),
                                      child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            margin: EdgeInsets.only(
                                                left: 20.w,
                                                right: 20.w,
                                                top: 10.h),
                                            height: 5.h,
                                            decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius:
                                                  BorderRadius.circular(10.r),
                                            ),
                                            child: ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(10.r),
                                              child: LinearProgressIndicator(
                                                // value: profileCompletion.clamp(
                                                //     0.0, 1.0),
                                                value: (((mentorData.data!
                                                                    .profileCompletion ??
                                                                0.0) /
                                                            100)
                                                        .clamp(0.0, 1.0))
                                                    .toDouble(),
                                                // backgroundColor:
                                                //     Colors.transparent,
                                                backgroundColor: themeMode ==
                                                        ThemeMode.light
                                                    ? const Color(0xFFE0E0E0)
                                                    : const Color(0xFF2A2A2A),

                                                valueColor:
                                                    AlwaysStoppedAnimation<
                                                        Color>(
                                                  // Color(0xFF008080),
                                                  themeMode == ThemeMode.dark
                                                      ? Color(0xFF008080)
                                                      : Color(0xFF1B1B1B),
                                                ),
                                                minHeight: 20.h,
                                              ),
                                            ),
                                          ),
                                          SizedBox(height: 12.h),
                                          Container(
                                            margin:
                                                EdgeInsets.only(right: 16.w),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Padding(
                                                  padding: EdgeInsets.symmetric(
                                                      horizontal: 20.w),
                                                  child: Text(
                                                    "Profile Completed",
                                                    style: GoogleFonts.roboto(
                                                      fontSize: 14.sp,
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      // color: Color.fromARGB(
                                                      //     204, 0, 0, 0),
                                                      color: themeMode ==
                                                              ThemeMode.dark
                                                          ? Color.fromARGB(
                                                              204, 0, 0, 0)
                                                          : Colors.white,
                                                    ),
                                                  ),
                                                ),
                                                Text(
                                                  //  "${(profileCompletion * 100).toInt()}%",
                                                  "${(mentorData.data!.profileCompletion ?? 0.0).toStringAsFixed(0)}%",
                                                  style: GoogleFonts.roboto(
                                                    fontSize: 14.sp,
                                                    fontWeight: FontWeight.w400,
                                                    color: themeMode ==
                                                            ThemeMode.dark
                                                        ? Color.fromARGB(
                                                            204, 0, 0, 0)
                                                        : Colors.white,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Container(
                                            margin: EdgeInsets.only(
                                                left: 15.w,
                                                right: 20.w,
                                                top: 16.h),
                                            child: Row(
                                              children: [
                                                ClipOval(
                                                  child: Image.network(
                                                    // profileImage['profile_picture']
                                                    //         ?.toString() ??
                                                    //     "https://upload.wikimedia.org/wikipedia/commons/8/89/Portrait_Placeholder.png",
                                                    mentorData
                                                            .data!.profilePic ??
                                                        "https://upload.wikimedia.org/wikipedia/commons/8/89/Portrait_Placeholder.png",
                                                    fit: BoxFit.cover,
                                                    height: 50.w,
                                                    width: 50.w,
                                                    errorBuilder: (context,
                                                        error, stackTrace) {
                                                      return ClipOval(
                                                        child: Image.network(
                                                          "https://upload.wikimedia.org/wikipedia/commons/8/89/Portrait_Placeholder.png",
                                                          fit: BoxFit.cover,
                                                          height: 50.w,
                                                          width: 50.w,
                                                        ),
                                                      );
                                                    },
                                                  ),
                                                ),
                                                SizedBox(width: 10.w),
                                                Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Text(
                                                      // "Mike Pena",
                                                      "${mentorData.data!.fullName ?? "Mentor"}!",
                                                      style: GoogleFonts.roboto(
                                                        fontSize: 16.sp,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        color: themeMode ==
                                                                ThemeMode.dark
                                                            ? Color.fromARGB(
                                                                204, 0, 0, 0)
                                                            : Colors.white,
                                                      ),
                                                    ),
                                                    Text(
                                                      "Placement | Interview",
                                                      style: GoogleFonts.roboto(
                                                        fontSize: 14.sp,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        color: themeMode ==
                                                                ThemeMode.dark
                                                            ? Color.fromARGB(
                                                                204, 0, 0, 0)
                                                            : Colors.white,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),
                                          Container(
                                            margin: EdgeInsets.only(
                                                left: 20.w,
                                                right: 15.w,
                                                top: 16.h),
                                            child: Text(
                                              // "With over 5 years of experience, "
                                              // "I've guided 300+ students to land jobs "
                                              // "in top companies like Google, TCS, and Deloitte. "
                                              // "My sessions focus on mock interviews, resume building, "
                                              // "and effective communication",
                                              mentorData.data!.description ??
                                                  "No descripion",
                                              style: GoogleFonts.roboto(
                                                fontSize: 15.sp,
                                                fontWeight: FontWeight.w400,
                                                color:
                                                    themeMode == ThemeMode.dark
                                                        ? Color.fromARGB(
                                                            204, 0, 0, 0)
                                                        : Colors.white,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.only(
                                        left: 20.w, right: 20.w, top: 20.h),
                                    child: Text(
                                      "Your Bids",
                                      style: GoogleFonts.inter(
                                        fontSize: 20.sp,
                                        fontWeight: FontWeight.w600,
                                        //color: Color(0xFF1B1B1B),
                                        color: themeMode == ThemeMode.dark
                                            ? Color(0xFF1B1B1B)
                                            : Colors.white,
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    height: 10.h,
                                  ),
                                  mentorData.data!.acceptedStudents!.isEmpty
                                      ? Center(
                                          child: Text(
                                            "No Accepted Student",
                                            style: GoogleFonts.inter(
                                              fontSize: 20.sp,
                                              fontWeight: FontWeight.w300,
                                              color: themeMode == ThemeMode.dark
                                                  ? Color(0xFF1B1B1B)
                                                  : Colors.white,
                                            ),
                                          ),
                                        )
                                      : ListView.builder(
                                          shrinkWrap: true,
                                          padding: EdgeInsets.zero,
                                          physics:
                                              NeverScrollableScrollPhysics(),
                                          itemCount: mentorData
                                              .data!.acceptedStudents!.length,
                                          itemBuilder: (context, index) {
                                            final student = mentorData
                                                .data!.acceptedStudents![index];
                                            return InkWell(
                                              onTap: () {
                                                log(box
                                                    .get("userid")
                                                    .toString());
                                                log(
                                                  mentorData
                                                      .data!
                                                      .acceptedStudents![index]
                                                      .id
                                                      .toString(),
                                                );
                                                Navigator.push(
                                                    context,
                                                    CupertinoPageRoute(
                                                      builder: (context) => ChatingPage(
                                                          id: box
                                                              .get("userid")
                                                              .toString(),
                                                          otherUesrid: mentorData
                                                              .data!
                                                              .acceptedStudents![
                                                                  index]
                                                              .id
                                                              .toString(),
                                                          name: student
                                                                  .fullName ??
                                                              "No Name"),
                                                    ));
                                              },
                                              child: MyContainer(
                                                image: student.profilePic ??
                                                    "https://flutter.github.io/assets-for-api-docs/assets/widgets/puffin.jpg",
                                                title:
                                                    student.fullName ?? "N/A",
                                                email:
                                                    student.email ?? "No Email",
                                                description:
                                                    student.description ?? "",
                                              ),
                                            );
                                          },
                                        ),
                                  SizedBox(height: 10.h),
                                ],
                              );
                            },
                            error: (error, stackTrace) {
                              log(stackTrace.toString());
                              return Center(
                                child: Text(error.toString()),
                              );
                            },
                            loading: () => Center(
                              child: CircularProgressIndicator(),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.only(left: 20.w, top: 10.h),
                            child: Row(
                              children: [
                                Text(
                                  "New Request",
                                  style: GoogleFonts.roboto(
                                    fontSize: 18.sp,
                                    fontWeight: FontWeight.w600,
                                    //color: Color(0xFF1B1B1B),
                                    color: themeMode == ThemeMode.dark
                                        ? Color(0xFF1B1B1B)
                                        : Colors.white,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 10.h),
                          getRequestHomeData.when(
                            data: (requestData) {
                              WidgetsBinding.instance.addPostFrameCallback((_) {
                                setState(() {
                                  requestLenght =
                                      requestData.data.length.toString();
                                });
                              });

                              if (requestData.data.isEmpty) {
                                return Center(
                                  child: Text(
                                    "No Request Available",
                                    style: GoogleFonts.inter(
                                      fontSize: 20.sp,
                                      fontWeight: FontWeight.w300,
                                      //color: Color(0xFF1B1B1B),
                                      color: themeMode == ThemeMode.dark
                                          ? Color(0xFF1B1B1B)
                                          : Colors.white,
                                    ),
                                  ),
                                );
                              }

                              return ListView.builder(
                                padding: EdgeInsets.zero,
                                shrinkWrap: true,
                                physics: NeverScrollableScrollPhysics(),
                                itemCount: requestData.data.length,
                                itemBuilder: (context, index) {
                                  final student = requestData.data[index];
                                  return GetRequestStudentBody(
                                    image: student.studentProfile ??
                                        "https://upload.wikimedia.org/wikipedia/commons/8/89/Portrait_Placeholder.png",
                                    title: student.studentName,
                                    subtitle: student.studentType,
                                    email: student.studentEmail,
                                    phone: student.studentPhone,
                                    callBack: () async {
                                      final body = AcceptRequestBodyModel(
                                          requestId: requestData.data[index].id
                                              .toString());
                                      try {
                                        setState(() {
                                          isAccept = true;
                                        });

                                        final service =
                                            APIStateNetwork(createDio());
                                        final response =
                                            await service.acceptRequest(body);

                                        if (response.status == true) {
                                          api.sendNotificationMentor(
                                              title:
                                                  'Mentorship Request Accepted 🎉',
                                              b:
                                                  'Great news! Your mentorship request has been accepted.',
                                              user_Id:
                                                  student.studentId.toString());

                                          Fluttertoast.showToast(
                                              msg: response.message);
                                          ref.invalidate(
                                              getHomeMentorDataProvider);
                                          ref.invalidate(
                                              getRequestStudentController);
                                          ref.invalidate(myListingController);
                                        } else {
                                          // Fluttertoast.showToast(
                                          //     msg: response.message);
                                          Fluttertoast.showToast(
                                              msg:
                                                  "Please upgrade the membership for mentor",
                                              toastLength: Toast.LENGTH_LONG);
                                        }
                                      } catch (e, st) {
                                        log("${e.toString()} /n ${st.toString()}");
                                        Fluttertoast.showToast(
                                            msg: "Not Accept");
                                      } finally {
                                        setState(() {
                                          isAccept = false;
                                        });
                                      }
                                    },
                                  );
                                },
                              );
                            },
                            error: (error, stackTrace) {
                              log(stackTrace.toString());
                              return Center(
                                child: Text(error.toString()),
                              );
                            },
                            loading: () => Center(
                              child: CircularProgressIndicator(),
                            ),
                          ),
                          SizedBox(height: 20.h),
                        ],
                      ),
                    ),
                  )
                else
                  SingleChildScrollView(
                    child: Column(
                      children: [
                        Container(
                          height: 380.h,
                          width: double.infinity,
                          decoration: BoxDecoration(
                            // color: Colors.white,
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(20),
                              topRight: Radius.circular(20),
                              bottomLeft: Radius.circular(20),
                              bottomRight: Radius.circular(20),
                            ),
                          ),
                          child: Column(
                            children: [
                              HomePageBody(
                                callBack: (String category) {
                                  setState(() {
                                    filterQuery = category;
                                  });
                                },
                              ),
                              SizedBox(height: 10.h),
                              getHomeStudentData.when(
                                data: (data) {
                                  final mentors = filterQuery == "All" ||
                                          filterQuery.isEmpty
                                      ? data.mentors?.values
                                              .expand((list) => list)
                                              .toList() ??
                                          []
                                      : data.mentors?[filterQuery]?.toList() ??
                                          [];
                                  if (mentors.isEmpty) {
                                    return Center(
                                      child: Text(
                                        "No mentors available",
                                        style: GoogleFonts.roboto(
                                          fontSize: 14.sp,
                                          //color: Colors.white,
                                          color: themeMode == ThemeMode.dark
                                              ? Color(0xFF1B1B1B)
                                              : Colors.white,
                                        ),
                                      ),
                                    );
                                  }
                                  return SizedBox(
                                    height: 260.h,
                                    child: ListView.builder(
                                      scrollDirection: Axis.horizontal,
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 20.w),
                                      itemCount: mentors.length,
                                      itemBuilder: (context, index) {
                                        final mentor = mentors[index];

                                        return UserTabs(
                                          callBack: () {
                                            Navigator.push(
                                                context,
                                                CupertinoPageRoute(
                                                  builder: (context) =>
                                                      MentorDetailPage(
                                                          id: mentor.id ?? 0),
                                                ));
                                          },
                                          id: mentor.id ?? 0,
                                          fullname:
                                              mentor.fullName ?? "Unknown",
                                          dec: mentor.description ??
                                              "No description",
                                          servicetype: [
                                            mentor.serviceType ?? "N/A"
                                          ],
                                          image: mentor.profilePic ?? "",
                                          otherUserId: mentor.id.toString(),
                                        );
                                      },
                                    ),
                                  );
                                },
                                loading: () => const Center(
                                  child: CircularProgressIndicator(
                                      color: Color(0xff008080)),
                                ),
                                error: (error, stack) {
                                  log("Mentors Error: $error");
                                  log("StackTrace: $stack");
                                  return Center(
                                    child: Column(
                                      children: [
                                        Text(
                                          "Error loading mentors: $error",
                                          style: GoogleFonts.roboto(
                                              fontSize: 14.sp,
                                              color: Colors.white),
                                        ),
                                        ElevatedButton(
                                          onPressed: () => ref.refresh(
                                              getHomeStudentDataProvider),
                                          child: const Text("Retry"),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                        // SizedBox(height: 10.h),
                        Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Padding(
                                padding: EdgeInsets.symmetric(horizontal: 20.w),
                                child: Text(
                                  "Explore Trending Skills",
                                  style: GoogleFonts.roboto(
                                      fontSize: 18.sp,
                                      fontWeight: FontWeight.w600,
                                      color: themeMode == ThemeMode.dark
                                          ? Color(0xFF1B1B1B)
                                          : Colors.white),
                                ),
                              ),
                            ]),
                        SizedBox(height: 20.h),
                        getHomeStudentData.when(
                          data: (data) {
                            final skills = data.skills ?? [];
                            if (skills.isEmpty) {
                              return Center(
                                child: Text(
                                  "No skills available",
                                  style: GoogleFonts.roboto(
                                      fontSize: 14.sp, color: Colors.white),
                                ),
                              );
                            }
                            return SizedBox(
                              height: 145.h,
                              child: ListView.builder(
                                scrollDirection: Axis.horizontal,
                                padding: EdgeInsets.symmetric(horizontal: 20.w),
                                itemCount: skills.length,
                                itemBuilder: (context, index) {
                                  final skill = skills[index];
                                  return Padding(
                                    padding: EdgeInsets.only(right: 15.w),
                                    child: InkWell(
                                      onTap: () {
                                        Navigator.push(
                                            context,
                                            CupertinoPageRoute(
                                              builder: (context) =>
                                                  TrendingExprtPage(
                                                id: skill.id ?? 0,
                                              ),
                                            ));
                                      },
                                      child: Container(
                                        width: 120.w,
                                        decoration: BoxDecoration(
                                          color: newCard,
                                          border: Border.all(
                                              color: Color(0xff008080)),
                                          borderRadius:
                                              BorderRadius.circular(15.r),
                                        ),
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Container(
                                              width: 50.w,
                                              height: 50.h,
                                              decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                                image: DecorationImage(
                                                  image: NetworkImage(
                                                      skill.image ?? ""),
                                                  fit: BoxFit.cover,
                                                  onError: (exception,
                                                          stackTrace) =>
                                                      const AssetImage(
                                                          "assets/placeholder.png"),
                                                ),
                                              ),
                                            ),
                                            SizedBox(height: 10.h),
                                            Text(
                                              limitString(
                                                  skill.title ?? "Unknown", 18),
                                              style: GoogleFonts.roboto(
                                                fontSize: 12.sp,
                                                fontWeight: FontWeight.w600,
                                                color: textColor,
                                              ),
                                              textAlign: TextAlign.center,
                                            ),
                                            Text(
                                              skill.level
                                                      ?.toString()
                                                      .split('.')
                                                      .last ??
                                                  "N/A",
                                              style: GoogleFonts.roboto(
                                                fontSize: 10.sp,
                                                fontWeight: FontWeight.w400,
                                                color: textColor,
                                              ),
                                              textAlign: TextAlign.center,
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  );
                                },
                              ),
                            );
                          },
                          loading: () => const Center(
                            child: CircularProgressIndicator(
                                color: Color(0xff008080)),
                          ),
                          error: (error, stack) => Center(
                            child: Text(
                              "Error loading skills",
                              style: GoogleFonts.roboto(
                                  fontSize: 14.sp, color: Colors.white),
                            ),
                          ),
                        ),
                        /* SizedBox(
                          height: 20.h,
                        ),*/
                        Container(
                          height: 350.h,
                          width: double.infinity,
                          decoration: const BoxDecoration(
                            // color: Colors.white,
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(20),
                              topRight: Radius.circular(20),
                              bottomLeft: Radius.circular(20),
                              bottomRight: Radius.circular(20),
                            ),
                          ),
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Container(
                                    margin:
                                        EdgeInsets.only(left: 20.w, top: 20.h),
                                    child: Text(
                                      "Explore College Review",
                                      style: GoogleFonts.roboto(
                                        fontSize: 18.sp,
                                        fontWeight: FontWeight.w600,
                                        // color: Color(0xFF1B1B1B)

                                        color: themeMode == ThemeMode.dark
                                            ? Colors.black
                                            : Colors.white,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 20.h),
                              getHomeStudentData.when(
                                data: (data) {
                                  final colleges = data.colleges ?? [];
                                  if (colleges.isEmpty) {
                                    return Center(
                                      child: Text(
                                        "No colleges available",
                                        style: GoogleFonts.roboto(
                                            fontSize: 14.sp,
                                            color: Colors.white),
                                      ),
                                    );
                                  }

                                  return SizedBox(
                                    height: 260.h,
                                    child: ListView.builder(
                                      scrollDirection: Axis.horizontal,
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 20.w),
                                      itemCount: colleges.length,
                                      itemBuilder: (context, index) {
                                        final college = colleges[index];
                                        return Padding(
                                          padding: EdgeInsets.only(right: 15.w),
                                          child: Container(
                                            width: 195.w,
                                            decoration: BoxDecoration(
                                              color: newCard,
                                              border: Border.all(
                                                  color: Color(0xff008080)),
                                              borderRadius:
                                                  BorderRadius.circular(15.r),
                                            ),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                InkWell(
                                                  onTap: () {
                                                    Navigator.push(
                                                        context,
                                                        CupertinoPageRoute(
                                                          builder: (context) =>
                                                              CollegeDetailPage(
                                                                  college.id!),
                                                        ));
                                                  },
                                                  child: Padding(
                                                    padding: EdgeInsets.only(
                                                        top: 8.h,
                                                        left: 8.w,
                                                        right: 8.w),
                                                    child: ClipRRect(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              12.r),
                                                      child: Image.network(
                                                        college.image ??
                                                            "https://www.howardluksmd.com/wp-content/uploads/2021/10/featured-image-placeholder-728x404.jpg",
                                                        errorBuilder: (context,
                                                            error, stackTrace) {
                                                          return Image.network(
                                                            "https://www.howardluksmd.com/wp-content/uploads/2021/10/featured-image-placeholder-728x404.jpg",
                                                            width:
                                                                MediaQuery.of(
                                                                        context)
                                                                    .size
                                                                    .width,
                                                            height: 111.h,
                                                            fit: BoxFit.contain,
                                                          );
                                                        },
                                                        width: MediaQuery.of(
                                                                context)
                                                            .size
                                                            .width,
                                                        height: 111.h,
                                                        fit: BoxFit.contain,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Padding(
                                                  padding: EdgeInsets.all(8.w),
                                                  child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      Container(
                                                        padding:
                                                            EdgeInsets.only(
                                                                left: 10.w,
                                                                right: 10.w,
                                                                top: 5.h,
                                                                bottom: 5.h),
                                                        decoration: BoxDecoration(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        40.r),
                                                            color: Color(
                                                                0xFFDEDDEC)),
                                                        child: Text(
                                                          college.city ?? "N/A",
                                                          style: GoogleFonts
                                                              .roboto(
                                                                  fontSize:
                                                                      14.sp,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w400,
                                                                  color: Colors
                                                                      .black),
                                                        ),
                                                      ),
                                                      SizedBox(
                                                        height: 8.h,
                                                      ),
                                                      Row(
                                                        children: [
                                                          Container(
                                                              padding: EdgeInsets
                                                                  .only(
                                                                      left: 8.w,
                                                                      right:
                                                                          8.w,
                                                                      top: 5.h,
                                                                      bottom:
                                                                          5.h),
                                                              decoration: BoxDecoration(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(40
                                                                              .r),
                                                                  color: Color(
                                                                      0xFFDEDDEC)),
                                                              child: Row(
                                                                children: [
                                                                  Icon(
                                                                    Icons.star,
                                                                    color: Color(
                                                                        0xFF008080),
                                                                    size: 14.sp,
                                                                  ),
                                                                  Text(
                                                                    "${college.avgRating!.toStringAsFixed(1)} Rating",
                                                                    maxLines: 1,
                                                                    overflow:
                                                                        TextOverflow
                                                                            .ellipsis,
                                                                    style: GoogleFonts.inter(
                                                                        fontSize: 12
                                                                            .sp,
                                                                        fontWeight:
                                                                            FontWeight
                                                                                .w400,
                                                                        color: Color(
                                                                            0xFF2E2E2E)),
                                                                  )
                                                                ],
                                                              )),
                                                          SizedBox(
                                                            width: 5.w,
                                                          ),
                                                          Container(
                                                              padding: EdgeInsets
                                                                  .only(
                                                                      left: 8.w,
                                                                      right:
                                                                          8.w,
                                                                      top: 5.h,
                                                                      bottom:
                                                                          5.h),
                                                              decoration: BoxDecoration(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(40
                                                                              .r),
                                                                  color: Color(
                                                                      0xFFDEDDEC)),
                                                              child: Row(
                                                                children: [
                                                                  Text(
                                                                    "${college.totalReviews!} Review",
                                                                    maxLines: 1,
                                                                    overflow:
                                                                        TextOverflow
                                                                            .ellipsis,
                                                                    style: GoogleFonts.inter(
                                                                        fontSize: 12
                                                                            .sp,
                                                                        fontWeight:
                                                                            FontWeight
                                                                                .w400,
                                                                        color: Color(
                                                                            0xFF2E2E2E)),
                                                                  )
                                                                ],
                                                              )),
                                                        ],
                                                      ),
                                                      Divider(
                                                          color: Color(
                                                              0xFF1B1B1B)),
                                                      Text(
                                                        maxLines: 1,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        college.collegeName ??
                                                            "Unknown",
                                                        style:
                                                            GoogleFonts.roboto(
                                                                fontSize: 15.sp,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w600,
                                                                color: themeMode ==
                                                                        ThemeMode
                                                                            .dark
                                                                    ? Colors
                                                                        .black
                                                                    : Colors
                                                                        .white,
                                                                /*   color: themeMode == ThemeMode.dark
                                                                    ? Color.fromARGB(25, 0, 0, 0)
                                                                    : Colors.white,*/
                                                                letterSpacing:
                                                                    -0.5),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        );
                                      },
                                    ),
                                  );
                                },
                                loading: () => const Center(
                                  child: CircularProgressIndicator(
                                      color: Color(0xff008080)),
                                ),
                                error: (error, stack) => Center(
                                  child: Text(
                                    "Error loading colleges",
                                    style: GoogleFonts.roboto(
                                        fontSize: 14.sp, color: Colors.white),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        // SizedBox(height: 30.h),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 20.w),
                          child: Row(
                            children: [
                              Text(
                                "Top Companies",
                                style: GoogleFonts.roboto(
                                    fontSize: 18.sp,
                                    fontWeight: FontWeight.w600,
                                    color: themeMode == ThemeMode.dark
                                        ? Color(0xFF1B1B1B)
                                        : Colors.white),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 25.h),
                        getHomeStudentData.when(
                          data: (data) {
                            final companies = data.companies ?? [];
                            if (companies.isEmpty) {
                              return Center(
                                child: Text(
                                  "No companies available",
                                  style: GoogleFonts.roboto(
                                      fontSize: 14.sp, color: Colors.white),
                                ),
                              );
                            }
                            return SizedBox(
                              height: 270.h,
                              child: ListView.builder(
                                scrollDirection: Axis.horizontal,
                                padding: EdgeInsets.symmetric(horizontal: 20.w),
                                itemCount: companies.length,
                                itemBuilder: (context, index) {
                                  final company = companies[index];
                                  return Padding(
                                    padding: EdgeInsets.only(right: 15.w),
                                    child: Container(
                                      width: 195.w,
                                      decoration: BoxDecoration(
                                        color: newCard,
                                        border: Border.all(
                                            color: Color(0xff008080)
                                            // themeMode == ThemeMode.dark
                                            //     ?Color.fromARGB(25, 0, 0, 0)
                                            //     : Colors.white,
                                            ),
                                        borderRadius:
                                            BorderRadius.circular(15.r),
                                      ),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          InkWell(
                                            onTap: () {
                                              Navigator.push(
                                                  context,
                                                  CupertinoPageRoute(
                                                    builder: (context) =>
                                                        CompanyDetailPage(
                                                            company.id!),
                                                  ));
                                            },
                                            child: Padding(
                                              padding: EdgeInsets.only(
                                                  top: 8.h,
                                                  left: 8.w,
                                                  right: 8.w),
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(12.r),
                                                child: Image.network(
                                                  company.image ??
                                                      "https://www.howardluksmd.com/wp-content/uploads/2021/10/featured-image-placeholder-728x404.jpg",
                                                  width: MediaQuery.of(context)
                                                      .size
                                                      .width,
                                                  height: 111.h,
                                                  fit: BoxFit.contain,
                                                  //color: Colors.white,
                                                  errorBuilder: (context, error,
                                                      stackTrace) {
                                                    return Image.network(
                                                      "https://www.howardluksmd.com/wp-content/uploads/2021/10/featured-image-placeholder-728x404.jpg",
                                                      width:
                                                          MediaQuery.of(context)
                                                              .size
                                                              .width,
                                                      height: 111.h,
                                                      fit: BoxFit.contain,
                                                    );
                                                  },
                                                ),
                                              ),
                                            ),
                                          ),
                                          Padding(
                                            padding: EdgeInsets.all(8.w),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  padding: EdgeInsets.only(
                                                      left: 10.w,
                                                      right: 10.w,
                                                      top: 5.h,
                                                      bottom: 5.h),
                                                  decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              40.r),
                                                      color: Color(0xFFDEDDEC)),
                                                  child: Text(
                                                    company.city ?? "Unknown",
                                                    style: GoogleFonts.roboto(
                                                        fontSize: 14.sp,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        color:
                                                            Color(0xFF2E2E2E)),
                                                  ),
                                                ),
                                                SizedBox(
                                                  height: 8.h,
                                                ),
                                                Row(
                                                  children: [
                                                    Container(
                                                      padding: EdgeInsets.only(
                                                          left: 10.w,
                                                          right: 10.w,
                                                          top: 5.h,
                                                          bottom: 5.h),
                                                      decoration: BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      40.r),
                                                          color: Color(
                                                              0xFFDEDDEC)),
                                                      child: Row(
                                                        children: [
                                                          Icon(
                                                            Icons.star,
                                                            color: Color(
                                                                0xFF2E2E2E),
                                                            size: 14.sp,
                                                          ),
                                                          Text(
                                                            "${company.avgRating ?? "Unknown"} Rating",
                                                            style: GoogleFonts.roboto(
                                                                fontSize: 12.sp,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w400,
                                                                color: Color(
                                                                    0xFF2E2E2E)),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Expanded(
                                                      child: Container(
                                                          margin:
                                                              EdgeInsets.only(
                                                                  left: 8.w),
                                                          padding:
                                                              EdgeInsets.only(
                                                                  left: 8.w,
                                                                  right: 8.w,
                                                                  top: 5.h,
                                                                  bottom: 5.h),
                                                          decoration: BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          40.r),
                                                              color: Color(
                                                                  0xFFDEDDEC)),
                                                          child: Row(
                                                            children: [
                                                              Expanded(
                                                                child: Text(
                                                                  "${company.totalReviews!} Review",
                                                                  maxLines: 1,
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  style:
                                                                      GoogleFonts
                                                                          .inter(
                                                                    fontSize:
                                                                        12.sp,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w400,
                                                                    color: Color(
                                                                        0xFF2E2E2E),
                                                                  ),
                                                                ),
                                                              )
                                                            ],
                                                          )),
                                                    ),
                                                  ],
                                                ),
                                                SizedBox(
                                                  height: 5.h,
                                                ),
                                                Divider(color: Colors.white12),
                                                Text(
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  company.companyName ??
                                                      "Unknown",
                                                  style: GoogleFonts.roboto(
                                                      fontSize: 15.sp,
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      color: themeMode ==
                                                              ThemeMode.dark
                                                          ? Color(0xFF1B1B1B)
                                                          : Colors.white,
                                                      letterSpacing: -0.5),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  );
                                },
                              ),
                            );
                          },
                          loading: () => const Center(
                            child: CircularProgressIndicator(
                                color: Color(0xff008080)),
                          ),
                          error: (error, stack) => Center(
                            child: Text(
                              "Error loading companies",
                              style: GoogleFonts.roboto(
                                  fontSize: 14.sp, color: Colors.white),
                            ),
                          ),
                        ),
                        SizedBox(height: 30.h),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// Rest of the code (HomePageBody, UserTabs, Upertabs, MyContainer, NewContainer) remains unchanged
class HomePageBody extends ConsumerStatefulWidget {
  final Function callBack;
  const HomePageBody({super.key, required this.callBack});
  @override
  _HomePageBodyState createState() => _HomePageBodyState();
}

class _HomePageBodyState extends ConsumerState<HomePageBody> {
  int currentTabIndex = 0;
  @override
  Widget build(BuildContext context) {
    final getHomeStudentData = ref.watch(getHomeStudentDataProvider);
    final themeMode = ref.watch(themeProvider);

    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        // SizedBox(height: 10.h),

        Container(
          margin: EdgeInsets.symmetric(horizontal: 20.w),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                "Top Mentors",
                style: GoogleFonts.roboto(
                    color: themeMode == ThemeMode.dark
                        ? Color(0xFF1B1B1B)
                        : Colors.white,

                    // color: Color(0xFF1B1B1B),
                    fontSize: 20.sp,
                    fontWeight: FontWeight.w600),
              ),
              // Row(
              //   children: [
              //     Text(
              //       "Filters",
              //       style: GoogleFonts.roboto(
              //           color: Colors.white,
              //           fontSize: 20.sp,
              //           fontWeight: FontWeight.w600),
              //     ),
              //     SizedBox(width: 4.w),
              //     Image.asset("assets/filter.png"),
              //     SizedBox(width: 4.w),
              //     Image.asset("assets/search.png"),
              //   ],
              // ),
            ],
          ),
        ),

        SizedBox(height: 15.h),
        getHomeStudentData.when(
          data: (data) {
            final categories = data.mentors?.keys.toList() ?? [];
            return Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(width: 20.w),
                SizedBox(
                  height: 30.h,
                  width: MediaQuery.of(context).size.width - 40.w,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    shrinkWrap: true,
                    children: [
                      Upertabs(
                        title: "All",
                        callBack: () {
                          setState(() {
                            currentTabIndex = 0;
                          });
                          widget.callBack("All");
                        },
                        currentIndex: currentTabIndex,
                        index: 0,
                      ),
                      ...categories.asMap().entries.map((entry) {
                        final index = entry.key + 1;
                        final category = entry.value;
                        return Upertabs(
                          title: category,
                          callBack: () {
                            setState(() {
                              currentTabIndex = index;
                            });
                            widget.callBack(category);
                          },
                          currentIndex: currentTabIndex,
                          index: index,
                        );
                      }).toList(),
                    ],
                  ),
                ),
              ],
            );
          },
          loading: () => const Center(
            child: CircularProgressIndicator(color: Color(0xff008080)),
          ),
          error: (error, stack) => Center(
            child: Text(
              "Error loading categories",
              style: GoogleFonts.roboto(fontSize: 14.sp, color: Colors.white),
            ),
          ),
        ),

        SizedBox(height: 10.h),
      ],
    );
  }
}

class UserTabs extends ConsumerStatefulWidget {
  final int id;
  final String fullname;
  final String dec;
  final List<String> servicetype;
  final String image;
  final Function callBack;
  final String otherUserId;

  const UserTabs({
    super.key,
    required this.id,
    required this.fullname,
    required this.dec,
    required this.servicetype,
    required this.image,
    required this.callBack,
    required this.otherUserId,
  });

  @override
  ConsumerState<UserTabs> createState() => _UserTabsState();
}
/*
class _UserTabsState extends ConsumerState<UserTabs> {
  @override
  Widget build(BuildContext context) {
    var box = Hive.box("userdata");
    final themeMode = ref.watch(themeProvider);
    return Container(
      margin: EdgeInsets.all(10.sp),
      height: 300.h,
      width: 200.w,
      decoration: BoxDecoration(

          borderRadius: BorderRadius.circular(20.r),

        border: Border.all(
          color: themeMode == ThemeMode.dark
              ? Color.fromARGB(25, 0, 0, 0)
              : Colors.white,
        ),

      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [

          InkWell(
            onTap: () {
              widget.callBack();
            },
            child: Container(
              // margin: EdgeInsets.all(10.sp),
              height: 112.h,
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12.r),
                image: DecorationImage(

                  image: NetworkImage(widget.image),
                  fit: BoxFit.cover,

                  onError: (exception, stackTrace) => NetworkImage(
                      "https://thumbs.dreamstime.com/b/no-image-vector-symbol-missing-available-icon-gallery-moment-placeholder-246411909.jpg"),
                ),
              ),
            ),
          ),

          Container(
            // margin: EdgeInsets.all(10.sp),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // SizedBox(height: 10.h),
                Container(
                  margin: EdgeInsets.only(left: 10.sp, right: 10.sp),
                  child: Text(
                    widget.fullname,
                    style: GoogleFonts.roboto(
                        color: themeMode == ThemeMode.dark
                            ? Color.fromARGB(25, 0, 0, 0)
                            : Colors.white,
                        // color: Color(0xFF1B1B1B),
                        fontSize: 14.sp,
                        fontWeight: FontWeight.w600),
                  ),
                ),
                SizedBox(height: 5.h),
                Container(
                  margin: EdgeInsets.only(left: 10.sp, right: 10.sp),
                  child: Text(
                    widget.dec,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.roboto(
                        color: themeMode == ThemeMode.dark
                            ? Color.fromARGB(25, 0, 0, 0)
                            : Colors.white,
                        // color: Color(0xFF1B1B1B),
                        fontSize: 12.sp,
                        fontWeight: FontWeight.w400),
                  ),
                ),

                SizedBox(height: 5.h),
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  InkWell(
                    onTap: () {
                      log(box.get("userid").toString());
                      // Navigator.push(
                      //     context,
                      //     CupertinoPageRoute(
                      //       builder: (context) => ChatingPage(
                      //         id: box.get("userid").toString(),
                      //         name: widget.fullname,
                      //         otherUesrid: widget.otherUserId,
                      //       ),
                      //     ));

                      Navigator.push(
                          context,
                          CupertinoPageRoute(
                            builder: (context) =>
                                MentorDetailPage(id: widget.id ?? 0),
                          ));
                    },
                    child: Container(
                      height: 30.h,
                      width: 170.w,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Color(0xff008080),
                        //color: themeMode == ThemeMode.dark
                        //     ? Colors.white
                        //     : Color(0xFF1B1B1B),
                      ),
                      child: Center(
                        child: Text(
                          "Connect",
                          style: GoogleFonts.roboto(
                              fontSize: 12.sp,
                              fontWeight: FontWeight.w400,
                              letterSpacing: -0.30,
                              color: Colors.white),
                        ),
                      ),
                    ),
                  ),
                ])

                // Container(
                //   height: 0.5.h,
                //   decoration: BoxDecoration(
                //     color: Colors.grey.shade400,
                //   ),
                // ),
                // SizedBox(height: 10.h),
                // SizedBox(
                //   height: 30.h,
                //   child: ListView.builder(
                //     itemCount: widget.servicetype.length,
                //     physics: const NeverScrollableScrollPhysics(),
                //     shrinkWrap: true,
                //     scrollDirection: Axis.horizontal,
                //     itemBuilder: (context, index) {
                //       return Padding(
                //         padding: EdgeInsets.only(left: 0.w, right: 8.w),
                //         child: Container(
                //           height: 26.h,
                //           decoration: BoxDecoration(
                //               color: const Color.fromARGB(225, 222, 221, 236),
                //               borderRadius: BorderRadius.circular(50.r)),
                //           child: Padding(
                //             padding: EdgeInsets.symmetric(horizontal: 10.w),
                //             child: Center(
                //               child: Text(
                //                 widget.servicetype[index],
                //                 style: GoogleFonts.roboto(
                //                     fontSize: 12.sp,
                //                     fontWeight: FontWeight.w400,
                //                     letterSpacing: -0.30,
                //                     color: Color(0xFF1B1B1B)),
                //               ),
                //             ),
                //           ),
                //         ),
                //       );
                //     },
                //   ),
                // ),
              ],
            ),
          ),

          // ),
        ],
      ),
    );
  }
}*/

/*class _UserTabsState extends ConsumerState<UserTabs> {
  @override
  Widget build(BuildContext context) {
    var box = Hive.box("userdata");
    final themeMode = ref.watch(themeProvider);

    // Proper colors for dark/light mode
    final bool isDark = themeMode == ThemeMode.dark;
    final Color textColor = isDark ? Colors.black87: Colors.white;
    final Color borderColor = isDark ? Color(0xff008080) :Color(0xff008080);
    final Color cardBackground = isDark ? Colors.black54 : Colors.white;
    final Color newCard = isDark ?Color(0xFFF2F0EF)!: Colors.black;

    return Container(
      margin: EdgeInsets.all(10.sp),
      height: 300.h,
      width: 200.w,

      decoration: BoxDecoration(
        color: newCard,
        // color: cardBackground,
        borderRadius: BorderRadius.circular(20.r),
        border: Border.all(color:Color(0xff008080)  , width: 1),
      ),
      child: Column(
        children: [

          Stack(children: [

            InkWell(
              onTap: (){},
              borderRadius: BorderRadius.vertical(top: Radius.circular(20.r)),
              child: ClipRRect(
                borderRadius: BorderRadius.vertical(top: Radius.circular(20.r)),
                child: SizedBox(
                  height: 300.h,
                  width: double.infinity,
                  child: Image.network(
                    widget.image,
                    fit: BoxFit.cover,
                    loadingBuilder: (context, child, loadingProgress) {
                      if (loadingProgress == null) return child;
                      return Container(color: Colors.grey[300]); // Optional loader
                    },
                    errorBuilder: (context, error, stackTrace) {
                      return Image.network(
                        "https://thumbs.dreamstime.com/b/no-image-vector-symbol-missing-available-icon-gallery-moment-placeholder-246411909.jpg",
                        fit: BoxFit.fill,
                      );
                    },
                  ),
                ),
              ),
            ),


          ],)
          // Profile Image with proper error handling


        ],
      ),
    );
  }
}*/

class _UserTabsState extends ConsumerState<UserTabs> {
  @override
  Widget build(BuildContext context) {
    var box = Hive.box("userdata");
    final themeMode = ref.watch(themeProvider);

    final bool isDark = themeMode == ThemeMode.dark;
    final Color textColor = isDark ? Colors.black87 : Colors.white;
    final Color borderColor = Color(0xff008080);
    final Color cardBackground = isDark ? Colors.black54 : Colors.white;
    final Color newCard = isDark ? Color(0xFFF2F0EF) : Colors.black;

    return Container(
      margin: EdgeInsets.all(10.sp),
      height: 300.h,
      width: 180.w,
      // width: 200.w,
      decoration: BoxDecoration(
        color: newCard,
        borderRadius: BorderRadius.circular(20.r),
        border: Border.all(color: borderColor, width: 1),
      ),
      child: Stack(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.vertical(
                top: Radius.circular(20.r), bottom: Radius.circular(20.r)),
            child: InkWell(
              onTap: () {},
              borderRadius: BorderRadius.vertical(
                  top: Radius.circular(20.r), bottom: Radius.circular(20.r)),
              child: SizedBox(
                height: 300.h,
                // height: 150.h, // Ya 180.h jo bhi achha lage - half ya thoda zyada
                width: double.infinity,
                child: Image.network(
                  widget.image,
                  fit: BoxFit.cover,
                  loadingBuilder: (context, child, loadingProgress) {
                    if (loadingProgress == null) return child;
                    return Container(color: Colors.grey[300]);
                  },
                  errorBuilder: (context, error, stackTrace) {
                    return Image.network(
                      "https://thumbs.dreamstime.com/b/no-image-vector-symbol-missing-available-icon-gallery-moment-placeholder-246411909.jpg",
                      fit: BoxFit.cover,
                    );
                  },
                ),
              ),
            ),
          ),

          // Details Section
          Positioned(
            bottom: 10.h,
            child: Padding(
              padding: EdgeInsets.all(12.sp),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.fullname,
                    style: GoogleFonts.roboto(
                      color: Colors.white,
                      // textColor,
                      // themeMode == ThemeMode.dark
                      //     ? Color.fromARGB(25, 0, 0, 0)
                      //     : Colors.white,
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w600,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  SizedBox(height: 6.h),
                  Text(
                    widget.dec,
                    style: GoogleFonts.roboto(
                      color: Colors.white,
                      // textColor,
                      fontSize: 12.sp,
                      fontWeight: FontWeight.w400,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  SizedBox(height: 12.h),
                  Center(
                    child: SizedBox(
                      height: 36.h,
                      width: 155.w,
                      child: ElevatedButton(
                        onPressed: () {
                          log(box.get("userid").toString());
                          Navigator.push(
                            context,
                            CupertinoPageRoute(
                              builder: (context) =>
                                  MentorDetailPage(id: widget.id ?? 0),
                            ),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xff008080),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10.r),
                          ),
                        ),
                        child: Text(
                          "Connect",
                          style: GoogleFonts.roboto(
                            fontSize: 13.sp,
                            fontWeight: FontWeight.w500,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Baaki content yahan aayega (name, bio, buttons etc.)
          // Expanded( // Yeh important hai - baaki jagah ko fill karega
          //   child: Padding(
          //     padding: EdgeInsets.all(12.sp),
          //     child: Column(
          //       mainAxisAlignment: MainAxisAlignment.center,
          //       children: [
          //         Text(
          //           "User Name", // Ya widget.name ya jo bhi ho
          //           style: TextStyle(
          //             color: textColor,
          //             fontSize: 18.sp,
          //             fontWeight: FontWeight.bold,
          //           ),
          //           textAlign: TextAlign.center,
          //         ),
          //         SizedBox(height: 8.h),
          //         Text(
          //           "Bio or description here",
          //           style: TextStyle(color: textColor.withOpacity(0.8), fontSize: 14.sp),
          //           textAlign: TextAlign.center,
          //           maxLines: 2,
          //           overflow: TextOverflow.ellipsis,
          //         ),
          //         // Yahan buttons ya aur details add kar sakte ho
          //       ],
          //     ),
          //   ),
          // ),
        ],
      ),
    );
  }
}

class Upertabs extends StatelessWidget {
  final String title;
  final Function callBack;
  final int currentIndex;
  final int index;

  const Upertabs({
    super.key,
    required this.title,
    required this.callBack,
    required this.currentIndex,
    required this.index,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 4.w, right: 8.w),
      child: GestureDetector(
        onTap: () => callBack(),
        child: Container(
          height: 30.h,
          decoration: BoxDecoration(
              color: currentIndex == index
                  ? const Color(0xff008080)
                  : const Color.fromARGB(225, 222, 221, 236),
              borderRadius: BorderRadius.circular(50.r)),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 10.w),
            child: Center(
              child: Text(
                title,
                style: GoogleFonts.roboto(
                    fontSize: 12.sp,
                    fontWeight: FontWeight.w400,
                    letterSpacing: -0.30,
                    color: currentIndex == index
                        ? Colors.white
                        : Color(0xFF1B1B1B)),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class MyContainer extends ConsumerWidget {
  final String image;
  final String title;
  final String email;
  final String description;
  const MyContainer({
    super.key,
    required this.image,
    required this.title,
    required this.email,
    required this.description,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeMode = ref.watch(themeProvider);
    return Padding(
      padding:
          EdgeInsets.only(top: 10.h, left: 20.w, right: 20.w, bottom: 10.h),
      child: Container(
        padding: EdgeInsets.all(14.w),
        decoration: BoxDecoration(
          //  color: Colors.white,
          color: themeMode == ThemeMode.dark ? Colors.white : Color(0xFF008080),
          borderRadius: BorderRadius.circular(18.r),
          border: Border.all(color: Color(0xff008080)),
          boxShadow: [
            BoxShadow(
              color: Color(0xFF1B1B1B),
              blurRadius: 6,
              offset: Offset(0, 3),
            )
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(12.r),
              child: Image.network(
                image,
                height: 80.h,
                width: 80.w,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) => Image.network(
                  "https://t4.ftcdn.net/jpg/05/07/58/41/360_F_507584110_KNIfe7d3hUAEpraq10J7MCPmtny8EH7A.jpg",
                  height: 80.h,
                  width: 80.w,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            SizedBox(width: 12.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: GoogleFonts.roboto(
                      // color: Color(0xFF1B1B1B),
                      color: themeMode == ThemeMode.dark
                          ? Color(0xFF1B1B1B)
                          : Colors.white,
                      fontSize: 16.sp,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(height: 4.h),
                  Row(
                    children: [
                      Icon(
                        Icons.email_outlined,
                        size: 14.sp,
                        color: themeMode == ThemeMode.dark
                            ? Color(0xFF1B1B1B)
                            : Colors.white,
                      ),
                      SizedBox(width: 5.w),
                      Expanded(
                        child: Text(
                          email,
                          style: GoogleFonts.roboto(
                            fontSize: 13.sp,
                            // color: Colors.grey[700],
                            color: themeMode == ThemeMode.dark
                                ? Color(0xFF1B1B1B)
                                : Colors.white,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 6.h),
                  Text(
                    description.isNotEmpty
                        ? description
                        : "No Description Available",
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.roboto(
                      fontSize: 12.sp,
                      // color: Color(0xFF1B1B1B)87,
                      color: themeMode == ThemeMode.dark
                          ? Color(0xFF1B1B1B)
                          : Colors.white,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class GetRequestStudentBody extends ConsumerStatefulWidget {
  final String image;
  final String title;
  final String subtitle;
  final String email;
  final String phone;
  final Function callBack;

  const GetRequestStudentBody({
    super.key,
    required this.image,
    required this.title,
    required this.subtitle,
    required this.email,
    required this.phone,
    required this.callBack,
  });

  @override
  ConsumerState<GetRequestStudentBody> createState() =>
      _GetRequestStudentBodyState();
}

class _GetRequestStudentBodyState extends ConsumerState<GetRequestStudentBody> {
  bool isLoading = false;

  @override
  Widget build(BuildContext context) {
    final themeMode = ref.watch(themeProvider);
    return Padding(
      padding:
          EdgeInsets.only(top: 10.h, left: 16.w, right: 16.w, bottom: 10.h),
      child: Container(
        padding: EdgeInsets.all(14.w),
        decoration: BoxDecoration(
          // color: Colors.white,
          color: themeMode == ThemeMode.dark ? Colors.white : Color(0xFF008080),
          borderRadius: BorderRadius.circular(16.r),
          border: Border.all(color: Color(0xff008080)),
          boxShadow: [
            BoxShadow(
              color: Color(0xFF1B1B1B),
              blurRadius: 6,
              offset: Offset(0, 3),
            )
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(12.r),
              child: Image.network(
                widget.image,
                height: 80.h,
                width: 80.w,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) => Icon(
                  Icons.person,
                  size: 70,
                  color: Colors.grey,
                ),
              ),
            ),
            SizedBox(width: 12.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.title,
                    style: GoogleFonts.roboto(
                      fontSize: 16.sp,
                      fontWeight: FontWeight.w600,
                      color: themeMode == ThemeMode.dark
                          ? Color(0xFF1B1B1B)
                          : Colors.white,
                    ),
                  ),
                  SizedBox(height: 4.h),
                  Text(
                    widget.subtitle,
                    style: GoogleFonts.roboto(
                      fontSize: 13.sp,
                      //color: Colors.blueGrey,
                      color: themeMode == ThemeMode.dark
                          ? Colors.blueGrey
                          : Colors.white,
                    ),
                  ),
                  SizedBox(height: 6.h),
                  Row(
                    children: [
                      Icon(Icons.email_outlined,
                          size: 14.sp,
                          color: themeMode == ThemeMode.dark
                              ? Colors.grey
                              : Colors.white),
                      SizedBox(width: 4.w),
                      Expanded(
                        child: Text(
                          widget.email,
                          style: GoogleFonts.roboto(
                              fontSize: 12.sp,
                              //color: Colors.grey[700],
                              color: themeMode == ThemeMode.dark
                                  ? Colors.grey[700]
                                  : Colors.white),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 4.h),
                  Row(
                    children: [
                      Icon(Icons.phone,
                          size: 14.sp,
                          color: themeMode == ThemeMode.dark
                              ? Colors.grey
                              : Colors.white),
                      SizedBox(width: 4.w),
                      Text(
                        widget.phone,
                        style: GoogleFonts.roboto(
                            fontSize: 12.sp,
                            color: themeMode == ThemeMode.dark
                                ? Colors.grey[700]
                                : Colors.white),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: isLoading
                  ? SizedBox(
                      height: 35.h,
                      width: 35.w,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.green,
                      ),
                    )
                  : ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.greenAccent.shade100,
                        foregroundColor: Color(0xFF1B1B1B),
                        padding: EdgeInsets.symmetric(
                            horizontal: 16.w, vertical: 10.h),
                      ),
                      onPressed: () async {
                        setState(() => isLoading = true);

                        await widget.callBack();

                        setState(() => isLoading = false);
                      },
                      child: Text(
                        "Accept",
                        style: GoogleFonts.inter(
                          fontSize: 14.sp,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

/*
import 'dart:developer';
import 'package:educationapp/complete/complete.page.dart';
import 'package:educationapp/coreFolder/Controller/themeController.dart';
import 'package:educationapp/coreFolder/Controller/userProfileController.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hive/hive.dart';
import 'package:intl/intl.dart';

class ProfilePage extends ConsumerStatefulWidget {
  ProfilePage({
    super.key,
  });
  @override
  ConsumerState<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends ConsumerState<ProfilePage> {
  @override
  Widget build(BuildContext context) {
    var box = Hive.box('userdata');
    final userType = box.get("userType");
    final userProfileProvider = ref.watch(userProfileController);
    final themeMode = ref.watch(themeProvider);
    return Scaffold(
      body: userProfileProvider.when(
        data: (userProfile) => SingleChildScrollView(

          child:

          Stack(
            children: [
              Column(
                children: [
                  Container(
                    height: 200.h,
                    width: double.infinity,
                    color: const Color(0xff008080),
                  ),
                  Container(
                    // color: Colors.white,
                    color: themeMode == ThemeMode.light
                        ? Color(0xFF1B1B1B)
                        : Colors.white,
                    child: Container(
                      width: double.infinity,
                      margin: EdgeInsets.only(top: 100.h),
                      child: SingleChildScrollView(
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                height: 20.h,
                              ),
                              Center(
                                child: Text(
                                  userProfile.data!.fullName ?? "No Name",
                                  style: GoogleFonts.roboto(
                                    fontSize: 24.sp,
                                    fontWeight: FontWeight.w600,
                                    color: themeMode == ThemeMode.dark
                                        ? Color(0xFF1B1B1B)
                                        : Colors.white,
                                  ),
                                ),
                              ),
                              Center(
                                child: Padding(
                                  padding: EdgeInsets.only(
                                    left: 15.w,
                                    right: 15.w,
                                  ),
                                  child: Text(
                                    textAlign: TextAlign.center,
                                    //'College: ${profile.usersField ?? 'N/A'} - Company: ${profile.companiesWorked?.toString() ?? 'N/A'}',
                                    "${userProfile.data!.highestQualification ?? "No qualification "}",
                                    style: GoogleFonts.roboto(
                                      fontSize: 16.sp,
                                      fontWeight: FontWeight.w600,
                                      // color: const Color(0xff666666),
                                      color: themeMode == ThemeMode.dark
                                          ? Color(0xff666666)
                                          : Colors.white,
                                    ),
                                  ),
                                ),
                              ),
                              Center(
                                  child: Wrap(
                                spacing: 10.w,
                                runSpacing: 5.h,
                                children: userProfile.data!.skills!
                                    .map<Widget>((skill) => Text(
                                          skill.toString(),
                                          style: GoogleFonts.roboto(
                                            fontSize: 16.sp,
                                            fontWeight: FontWeight.w600,
                                            //color: Color(0xFF1B1B1B),
                                            color: themeMode == ThemeMode.dark
                                                ? Color(0xff666666)
                                                : Colors.white,
                                          ),
                                        ))
                                    .toList(),
                              )),
                              SizedBox(
                                height: 20.h,
                              ),
                              Divider(),
                              Container(
                                margin: EdgeInsets.only(left: 20.w, top: 15.h),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Text(
                                      "About",
                                      style: GoogleFonts.roboto(
                                        fontSize: 20.sp,
                                        fontWeight: FontWeight.w600,
                                        color: themeMode == ThemeMode.dark
                                            ? Color(0xFF1B1B1B)
                                            : Colors.white,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(height: 3.h),
                              Container(
                                margin: EdgeInsets.only(left: 20.w),
                                width: 400.w,
                                child: Text(
                                  userProfile.data!.fullName ?? "No Name",
                                      // "No description",
                                  style: GoogleFonts.roboto(
                                    fontSize: 16.sp,
                                    fontWeight: FontWeight.w600,

                                    ///color: const Color(0xff666666),
                                    color: themeMode == ThemeMode.dark
                                        ? Color(0xff666666)
                                        : Colors.white,
                                  ),
                                ),
                              ),

                              SizedBox(height: 3.h),
                              Container(
                                margin: EdgeInsets.only(left: 20.w),
                                width: 400.w,
                                child: Text(
                                  userProfile.data!.description ??
                                      "No description",
                                  style: GoogleFonts.roboto(
                                    fontSize: 16.sp,
                                    fontWeight: FontWeight.w600,

                                    ///color: const Color(0xff666666),
                                    color: themeMode == ThemeMode.dark
                                        ? Color(0xff666666)
                                        : Colors.white,
                                  ),
                                ),
                              ),
                              if (userType != "Student") ...[
                                Padding(
                                  padding: EdgeInsets.only(left: 20.w),
                                  child: Text(
                                    "Total Experience ${userProfile.data!.totalExperience ?? 0}",
                                    style: GoogleFonts.roboto(
                                      fontSize: 16.sp,
                                      fontWeight: FontWeight.w600,
                                      // color: const Color(0xff666666),
                                      color: themeMode == ThemeMode.dark
                                          ? Color(0xff666666)
                                          : Colors.white,
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(left: 20.w, top: 4.h),
                                  child: Text(
                                    userProfile.data!.jobCompanyName
                                            ?.toString() ??
                                        'company',
                                    style: GoogleFonts.roboto(
                                      fontSize: 16.sp,
                                      fontWeight: FontWeight.w600,
                                      // color: Color(0xff666666),
                                      color: themeMode == ThemeMode.dark
                                          ? Color(0xff666666)
                                          : Colors.white,
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(left: 20.w, top: 4.h),
                                  child: Text(
                                    userProfile.data!.jobLocation ?? "location",
                                    style: GoogleFonts.roboto(
                                      fontSize: 16.sp,
                                      fontWeight: FontWeight.w600,
                                      // color: Color(0xff666666),
                                      color: themeMode == ThemeMode.dark
                                          ? Color(0xff666666)
                                          : Colors.white,
                                    ),
                                  ),
                                ),
                              ],
                              SizedBox(
                                height: 10.h,
                              ),

                              Divider(),

                              Container(
                                  margin:
                                      EdgeInsets.only(left: 20.w, top: 15.h),
                                  child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              "Educations",
                                              style: GoogleFonts.roboto(
                                                fontSize: 20.sp,
                                                fontWeight: FontWeight.w600,
                                                color:
                                                    themeMode == ThemeMode.dark
                                                        ? Color(0xFF1B1B1B)
                                                        : Colors.white,
                                              ),
                                            ),
                                            SizedBox(height: 5.h),
                                            Text(
                                              userProfile.data!
                                                      .highestQualification ??
                                                  "qualification",
                                              style: GoogleFonts.roboto(
                                                fontSize: 16.sp,
                                                fontWeight: FontWeight.w600,
                                                // color: const Color(0xff666666),
                                                color:
                                                    themeMode == ThemeMode.dark
                                                        ? Color(0xff666666)
                                                        : Colors.white,
                                              ),
                                            ),
                                            if (userType == "Student") ...[
                                              Text(
                                                userProfile.data!
                                                        .collegeOrInstituteName ??
                                                    "collage",
                                                style: GoogleFonts.roboto(
                                                  fontSize: 16.sp,
                                                  fontWeight: FontWeight.w600,
                                                  // color: const Color(0xff666666),
                                                  color: themeMode ==
                                                          ThemeMode.dark
                                                      ? Color(0xff666666)
                                                      : Colors.white,
                                                ),
                                              ),
                                              // Text(
                                              //   userProfile
                                              //           .data!.educationYear ??
                                              //       "year",
                                              //   style: GoogleFonts.roboto(
                                              //     fontSize: 16.sp,
                                              //     fontWeight: FontWeight.w600,
                                              //     // color: const Color(0xff666666),
                                              //     color: themeMode ==
                                              //             ThemeMode.dark
                                              //         ? Color(0xff666666)
                                              //         : Colors.white,
                                              //   ),
                                              // ),
                                            ],
                                          ],
                                        ),
                                      ])),
                              SizedBox(
                                height: 10.h,
                              ),
                              Divider(),
                              Container(
                                margin: EdgeInsets.only(left: 20.w, top: 15.h),
                                child: Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "Skills",
                                            style: GoogleFonts.roboto(
                                              fontSize: 20.sp,
                                              fontWeight: FontWeight.w600,
                                              color: themeMode == ThemeMode.dark
                                                  ? Color(0xFF1B1B1B)
                                                  : Colors.white,
                                            ),
                                          ),
                                          SizedBox(height: 10.h),
                                          if (userProfile.data!.skills !=
                                                  null &&
                                              userProfile
                                                  .data!.skills!.isNotEmpty)
                                            Wrap(
                                              spacing: 10.w,
                                              runSpacing: 5.h,
                                              children: userProfile
                                                  .data!.skills!
                                                  .map<Widget>((skill) =>
                                                      Container(
                                                        padding: EdgeInsets
                                                            .symmetric(
                                                                horizontal:
                                                                    12.w,
                                                                vertical: 8.h),
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      20.r),
                                                          color: const Color(
                                                              0xffDEDDEC),
                                                        ),
                                                        child: Center(
                                                          child: Text(
                                                            skill.toString(),
                                                            style: GoogleFonts
                                                                .roboto(
                                                              fontSize: 14.sp,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600,
                                                              //color: Color(0xFF1B1B1B),
                                                              color: themeMode ==
                                                                      ThemeMode
                                                                          .dark
                                                                  ? Color(
                                                                      0xff666666)
                                                                  : Colors
                                                                      .white,
                                                            ),
                                                          ),
                                                        ),
                                                      ))
                                                  .toList(),
                                            )
                                          else
                                            Text(
                                              'No skills listed',
                                              style: GoogleFonts.roboto(
                                                fontSize: 15.sp,
                                                fontWeight: FontWeight.w600,
                                                // color: const Color(0xff666666),
                                                color:
                                                    themeMode == ThemeMode.dark
                                                        ? Color(0xff666666)
                                                        : Colors.white,
                                              ),
                                            ),
                                        ],
                                      ),
                                    ]),
                              ),
                              SizedBox(
                                height: 10.h,
                              ),
                              Divider(),
                              // Educations section
                              Container(
                                margin: EdgeInsets.only(left: 20.w, top: 15.h),
                                child: Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "Language",
                                            style: GoogleFonts.roboto(
                                              fontSize: 20.sp,
                                              fontWeight: FontWeight.w600,
                                              color: themeMode == ThemeMode.dark
                                                  ? Color(0xFF1B1B1B)
                                                  : Colors.white,
                                            ),
                                          ),
                                          SizedBox(height: 10.h),
                                          Text(
                                            (userProfile.data!.languageKnown ==
                                                        null ||
                                                    userProfile.data!
                                                        .languageKnown!.isEmpty)
                                                ? "No Language"
                                                : userProfile
                                                    .data!.languageKnown!,
                                            style: GoogleFonts.roboto(
                                              fontSize: 15.sp,
                                              fontWeight: FontWeight.w600,
                                              //color: const Color(0xff666666),
                                              color: themeMode == ThemeMode.dark
                                                  ? Color(0xff666666)
                                                  : Colors.white,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ]),
                              ),
                              Divider(),

                              Container(
                                margin: EdgeInsets.only(left: 20.w, top: 15.h),
                                child: Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "Github/Drive/Behance/link",
                                            style: GoogleFonts.roboto(
                                              fontSize: 20.sp,
                                              fontWeight: FontWeight.w600,
                                              color: themeMode == ThemeMode.dark
                                                  ? Color(0xFF1B1B1B)
                                                  : Colors.white,
                                            ),
                                          ),
                                          SizedBox(height: 10.h),
                                          Text(

                                                userProfile.data!.linkedinUser.toString(),

                                            style: GoogleFonts.roboto(
                                              fontSize: 15.sp,
                                              fontWeight: FontWeight.w600,
                                              //color: const Color(0xff666666),
                                              color: themeMode == ThemeMode.dark
                                                  ? Color(0xff666666)
                                                  : Colors.white,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ]),
                              ),

                              Divider(),


                              Container(
                                margin: EdgeInsets.only(left: 20.w, top: 15.h),
                                child: Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "Gender",
                                            style: GoogleFonts.roboto(
                                              fontSize: 20.sp,
                                              fontWeight: FontWeight.w600,
                                              color: themeMode == ThemeMode.dark
                                                  ? Color(0xFF1B1B1B)
                                                  : Colors.white,
                                            ),
                                          ),
                                          SizedBox(height: 10.h),
                                          Text(

                                            userProfile.data!.gender.toString(),

                                            style: GoogleFonts.roboto(
                                              fontSize: 15.sp,
                                              fontWeight: FontWeight.w600,
                                              //color: const Color(0xff666666),
                                              color: themeMode == ThemeMode.dark
                                                  ? Color(0xff666666)
                                                  : Colors.white,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ]),
                              ),


                              Divider(),


                              Container(
                                margin: EdgeInsets.only(left: 20.w, top: 15.h),
                                child: Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "DOB",
                                            style: GoogleFonts.roboto(
                                              fontSize: 20.sp,
                                              fontWeight: FontWeight.w600,
                                              color: themeMode == ThemeMode.dark
                                                  ? Color(0xFF1B1B1B)
                                                  : Colors.white,
                                            ),
                                          ),
                                          SizedBox(height: 10.h),
                                          Text(
                                            DateFormat('dd/MM/yyyy').format(userProfile.data!.dob!),  // Yeh line change karo
                                            style: GoogleFonts.roboto(
                                              fontSize: 15.sp,
                                              fontWeight: FontWeight.w600,
                                              color: themeMode == ThemeMode.dark
                                                  ? const Color(0xff666666)
                                                  : Colors.white,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ]),
                              ),



                              Divider(),
                              Container(
                                margin: EdgeInsets.only(left: 20.w, top: 15.h),
                                child: Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "Interest",
                                            style: GoogleFonts.roboto(
                                              fontSize: 20.sp,
                                              fontWeight: FontWeight.w600,
                                              color: themeMode == ThemeMode.dark
                                                  ? Color(0xFF1B1B1B)
                                                  : Colors.white,
                                            ),
                                          ),
                                          SizedBox(height: 10.h),
                                          Text(
                                            userProfile.data!.interest??"",
                                            style: GoogleFonts.roboto(
                                              fontSize: 15.sp,
                                              fontWeight: FontWeight.w600,
                                              color: themeMode == ThemeMode.dark
                                                  ? const Color(0xff666666)
                                                  : Colors.white,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ]),
                              ),



                              Divider(),
                              Container(
                                margin: EdgeInsets.only(left: 20.w, top: 15.h),
                                child: Text(
                                  "Contact",
                                  style: GoogleFonts.roboto(
                                    fontSize: 20.sp,
                                    fontWeight: FontWeight.w600,
                                    color: themeMode == ThemeMode.dark
                                        ? Color(0xFF1B1B1B)
                                        : Colors.white,
                                  ),
                                ),
                              ),


                              SizedBox(height: 10.h),
                              Container(
                                margin: EdgeInsets.only(
                                  left: 20.w,
                                ),
                                child: Text(
                                  "Phone: +91 ${userProfile.data!.phoneNumber ?? 'N/A'}",
                                  style: GoogleFonts.roboto(
                                    fontSize: 15.sp,
                                    fontWeight: FontWeight.w600,
                                    color: themeMode == ThemeMode.dark
                                        ? Color(0xff666666)
                                        : Colors.white,
                                  ),
                                ),
                              ),
                              Divider(),
                              Container(
                                margin: EdgeInsets.only(left: 20.w, top: 15.h),
                                child: Text(
                                  "Certificate",
                                  style: GoogleFonts.roboto(
                                    fontSize: 20.sp,
                                    fontWeight: FontWeight.w600,
                                    color: themeMode == ThemeMode.dark
                                        ? Color(0xFF1B1B1B)
                                        : Colors.white,
                                  ),
                                ),
                              ),

                  SizedBox(height: 20.h,),
                  userProfile.data!.certificate!=null?

                  Container(
                    margin: EdgeInsets.only(left: 20.w,right: 20.w),
                    child: ClipRRect(

                      borderRadius:
                      BorderRadius.circular(
                          20.r),
                      child: Image.network(
                        userProfile.data!.certificate!,
                        fit: BoxFit.cover,
                        width: 360.w,
                        height: 250.h,
                        errorBuilder: (context,
                            error,
                            stackTrace) =>
                            Column(
                              crossAxisAlignment:
                              CrossAxisAlignment
                                  .center,
                              mainAxisAlignment:
                              MainAxisAlignment
                                  .center,
                              children: [
                                Icon(
                                  Icons.upload_sharp,
                                  color:
                                  Color(0xFF008080),
                                  size: 30.sp,
                                ),
                                SizedBox(
                                  height: 10.h,
                                ),
                              ],
                            ),
                      ),
                    ),
                  )


                      :SizedBox(),
                              SizedBox(height: 20.h),
                            ]),
                      ),
                    ),
                  ),
                ],
              ),
              Positioned(
                top: 30.h,
                left: 20.w,
                right: 20.w,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Profile",
                      style: GoogleFonts.roboto(
                        fontSize: 20.sp,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
              Positioned(
                left: 0,
                right: 0,
                top: 110.h,
                child: Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Center(
                      child: ClipOval(
                        child: userProfile.data!.profilePic != null
                            ? Image.network(
                                userProfile.data!.profilePic!,
                                height: 182.w,
                                width: 182.w,
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) =>
                                    Image.network(
                                        "https://upload.wikimedia.org/wikipedia/commons/8/89/Portrait_Placeholder.png",
                                        height: 182.w,
                                        width: 182.w,
                                        fit: BoxFit.cover),
                              )
                            : Image.network(
                                "https://upload.wikimedia.org/wikipedia/commons/8/89/Portrait_Placeholder.png",
                                height: 182.w,
                                width: 182.w,
                                fit: BoxFit.cover),
                      ),
                    ),
                    Positioned(
                        left: 0,
                        right: -85,
                        bottom: -5,
                        child: InkWell(
                          onTap: () {
                            Navigator.push(
                                context,
                                CupertinoPageRoute(
                                  builder: (context) =>
                                      ProfileCompletionWidget(true),
                                ));
                          },
                          child: Container(
                              width: 50.w,
                              height: 50.h,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Color(0xff008080),
                              ),
                              child: Icon(
                                Icons.edit,
                                color: Colors.white,
                                size: 24.sp,
                              )),
                        )),
                  ],
                ),
              ),
            ],
          ),
        ),

        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, stack) {
          log(stack.toString());
          log(error.toString());
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('Error: $error'),
                ElevatedButton(
                  onPressed: () {},
                  child: const Text('Retry'),
                ),
              ],
            ),
          );
        },

      ),
    );
  }
}
*/



import 'dart:developer';
import 'package:educationapp/complete/complete.page.dart';
import 'package:educationapp/coreFolder/Controller/themeController.dart';
import 'package:educationapp/coreFolder/Controller/userProfileController.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hive/hive.dart';
import 'package:intl/intl.dart';

class ProfilePage extends ConsumerStatefulWidget {
  ProfilePage({
    super.key,
  });

  @override
  ConsumerState<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends ConsumerState<ProfilePage> {
  @override
  Widget build(BuildContext context) {
    var box = Hive.box('userdata');
    final userType = box.get("userType");
    final userProfileAsync = ref.watch(userProfileController);
    final themeMode = ref.watch(themeProvider);

    return Scaffold(
      body: userProfileAsync.when(
        data: (userProfile) {
          // Safely extract profile data
          final profileData = userProfile.data;

          if (profileData == null) {
            return const Center(
              child: Text(
                'No profile data available',
                style: TextStyle(fontSize: 18, color: Colors.grey),
              ),
            );
          }

          return SingleChildScrollView(
            child: Stack(
              children: [

                Column(
                  children: [
                    Container(
                      height: 200.h,
                      width: double.infinity,
                      color: const Color(0xff008080),
                    ),
                    Container(
                      color: themeMode == ThemeMode.light
                          ? Color(0xFF1B1B1B)
                          : Colors.white,
                      child: Container(
                        width: double.infinity,
                        margin: EdgeInsets.only(top: 100.h),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(height: 20.h),
                            Center(
                              child: Text(
                                profileData.fullName ?? "No Name",
                                style: GoogleFonts.roboto(
                                  fontSize: 24.sp,
                                  fontWeight: FontWeight.w600,
                                  color: themeMode == ThemeMode.dark
                                      ? Color(0xFF1B1B1B)
                                      : Colors.white,
                                ),
                              ),
                            ),
                            Center(
                              child: Padding(
                                padding: EdgeInsets.symmetric(horizontal: 15.w),
                                child: Text(
                                  profileData.highestQualification ??
                                      "No qualification",
                                  textAlign: TextAlign.center,
                                  style: GoogleFonts.roboto(
                                    fontSize: 16.sp,
                                    fontWeight: FontWeight.w600,
                                    color: themeMode == ThemeMode.dark
                                        ? Color(0xff666666)
                                        : Colors.white,
                                  ),
                                ),
                              ),
                            ),
                            Center(
                              child: Wrap(
                                spacing: 10.w,
                                runSpacing: 5.h,
                                children: (profileData.skills ?? [])
                                    .map<Widget>((skill) => Text(
                                  skill.toString(),
                                  style: GoogleFonts.roboto(
                                    fontSize: 16.sp,
                                    fontWeight: FontWeight.w600,
                                    color: themeMode == ThemeMode.dark
                                        ? Color(0xff666666)
                                        : Colors.white,
                                  ),
                                ))
                                    .toList(),
                              ),
                            ),
                            SizedBox(height: 20.h),
                            Divider(),
                            Container(
                              margin: EdgeInsets.only(left: 20.w, top: 15.h),
                              child: Text(
                                "About",
                                style: GoogleFonts.roboto(
                                  fontSize: 20.sp,
                                  fontWeight: FontWeight.w600,
                                  color: themeMode == ThemeMode.dark
                                      ? Color(0xFF1B1B1B)
                                      : Colors.white,
                                ),
                              ),
                            ),
                            SizedBox(height: 3.h),
                            Container(
                              margin: EdgeInsets.only(left: 20.w),
                              width: 400.w,
                              child: Text(
                                profileData.description ?? "No description",
                                style: GoogleFonts.roboto(
                                  fontSize: 16.sp,
                                  fontWeight: FontWeight.w600,
                                  color: themeMode == ThemeMode.dark
                                      ? Color(0xff666666)
                                      : Colors.white,
                                ),
                              ),
                            ),
                            if (userType != "Student") ...[
                              Padding(
                                padding: EdgeInsets.only(left: 20.w, top: 10.h),
                                child: Text(
                                  "Total Experience: ${profileData.totalExperience ?? 0} years",
                                  style: GoogleFonts.roboto(
                                    fontSize: 16.sp,
                                    fontWeight: FontWeight.w600,
                                    color: themeMode == ThemeMode.dark
                                        ? Color(0xff666666)
                                        : Colors.white,
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.only(left: 20.w, top: 4.h),
                                child: Text(
                                  profileData.jobCompanyName ?? 'No company',
                                  style: GoogleFonts.roboto(
                                    fontSize: 16.sp,
                                    fontWeight: FontWeight.w600,
                                    color: themeMode == ThemeMode.dark
                                        ? Color(0xff666666)
                                        : Colors.white,
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.only(left: 20.w, top: 4.h),
                                child: Text(
                                  profileData.jobLocation ?? "No location",
                                  style: GoogleFonts.roboto(
                                    fontSize: 16.sp,
                                    fontWeight: FontWeight.w600,
                                    color: themeMode == ThemeMode.dark
                                        ? Color(0xff666666)
                                        : Colors.white,
                                  ),
                                ),
                              ),
                            ],
                            SizedBox(height: 20.h),
                            Divider(),
                            // Educations
                            Container(
                              margin: EdgeInsets.only(left: 20.w, top: 15.h),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Education",
                                    style: GoogleFonts.roboto(
                                      fontSize: 20.sp,
                                      fontWeight: FontWeight.w600,
                                      color: themeMode == ThemeMode.dark
                                          ? Color(0xFF1B1B1B)
                                          : Colors.white,
                                    ),
                                  ),
                                  SizedBox(height: 5.h),
                                  Text(
                                    profileData.highestQualification ??
                                        "No qualification",
                                    style: GoogleFonts.roboto(
                                      fontSize: 16.sp,
                                      fontWeight: FontWeight.w600,
                                      color: themeMode == ThemeMode.dark
                                          ? Color(0xff666666)
                                          : Colors.white,
                                    ),
                                  ),
                                  if (userType == "Student") ...[
                                    Text(
                                      profileData.collegeOrInstituteName ??
                                          "No college",
                                      style: GoogleFonts.roboto(
                                        fontSize: 16.sp,
                                        fontWeight: FontWeight.w600,
                                        color: themeMode == ThemeMode.dark
                                            ? Color(0xff666666)
                                            : Colors.white,
                                      ),
                                    ),
                                  ],
                                ],
                              ),
                            ),
                            SizedBox(height: 10.h),
                            Divider(),
                            // Skills
                            Container(
                              margin: EdgeInsets.only(left: 20.w, top: 15.h),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Skills",
                                    style: GoogleFonts.roboto(
                                      fontSize: 20.sp,
                                      fontWeight: FontWeight.w600,
                                      color: themeMode == ThemeMode.dark
                                          ? Color(0xFF1B1B1B)
                                          : Colors.white,
                                    ),
                                  ),
                                  SizedBox(height: 10.h),
                                  if (profileData.skills != null &&
                                      profileData.skills!.isNotEmpty)
                                    Wrap(
                                      spacing: 10.w,
                                      runSpacing: 5.h,
                                      children: profileData.skills!
                                          .map<Widget>((skill) => Container(
                                        padding: EdgeInsets.symmetric(
                                            horizontal: 12.w,
                                            vertical: 8.h),
                                        decoration: BoxDecoration(
                                          borderRadius:
                                          BorderRadius.circular(20.r),
                                          color: const Color(0xffDEDDEC),
                                        ),
                                        child: Text(
                                          skill.toString(),
                                          style: GoogleFonts.roboto(
                                            fontSize: 14.sp,
                                            fontWeight: FontWeight.w600,
                                            color: themeMode ==
                                                ThemeMode.dark
                                                ? Color(0xff666666)
                                                : Color(0xFF1B1B1B),
                                          ),
                                        ),
                                      ))
                                          .toList(),
                                    )
                                  else
                                    Text(
                                      'No skills listed',
                                      style: GoogleFonts.roboto(
                                        fontSize: 15.sp,
                                        color: themeMode == ThemeMode.dark
                                            ? Color(0xff666666)
                                            : Colors.white,
                                      ),
                                    ),
                                ],
                              ),
                            ),
                            SizedBox(height: 10.h),
                            Divider(),
                            // Language
                            _buildInfoSection(
                              title: "Language",
                              value: profileData.languageKnown?.isNotEmpty == true
                                  ? profileData.languageKnown!
                                  : "No language specified",
                              themeMode: themeMode,
                            ),
                            Divider(),
                            // Links
                            _buildInfoSection(
                              title: "Github/Drive/Behance/LinkedIn",
                              value: profileData.linkedinUser ?? "Not provided",
                              themeMode: themeMode,
                            ),
                            Divider(),
                            // Gender
                            _buildInfoSection(
                              title: "Gender",
                              value: profileData.gender ?? "Not specified",
                              themeMode: themeMode,
                            ),
                            Divider(),
                            // DOB
                            _buildInfoSection(
                              title: "Date of Birth",
                              value: profileData.dob != null
                                  ? DateFormat('dd/MM/yyyy')
                                  .format(profileData.dob!)
                                  : "Not provided",
                              themeMode: themeMode,
                            ),
                            Divider(),
                            // Interest
                            _buildInfoSection(
                              title: "Interest",
                              value: profileData.interest ?? "None specified",
                              themeMode: themeMode,
                            ),
                            Divider(),
                            // Contact
                            Container(
                              margin: EdgeInsets.only(left: 20.w, top: 15.h),
                              child: Text(
                                "Contact",
                                style: GoogleFonts.roboto(
                                  fontSize: 20.sp,
                                  fontWeight: FontWeight.w600,
                                  color: themeMode == ThemeMode.dark
                                      ? Color(0xFF1B1B1B)
                                      : Colors.white,
                                ),
                              ),
                            ),
                            SizedBox(height: 10.h),
                            Container(
                              margin: EdgeInsets.only(left: 20.w),
                              child: Text(
                                "Phone: +91 ${profileData.phoneNumber ?? 'N/A'}",
                                style: GoogleFonts.roboto(
                                  fontSize: 15.sp,
                                  fontWeight: FontWeight.w600,
                                  color: themeMode == ThemeMode.dark
                                      ? Color(0xff666666)
                                      : Colors.white,
                                ),
                              ),
                            ),
                            Divider(),
                            // Certificate
                            Container(
                              margin: EdgeInsets.only(left: 20.w, top: 15.h),
                              child: Text(
                                "Certificate",
                                style: GoogleFonts.roboto(
                                  fontSize: 20.sp,
                                  fontWeight: FontWeight.w600,
                                  color: themeMode == ThemeMode.dark
                                      ? Color(0xFF1B1B1B)
                                      : Colors.white,
                                ),
                              ),
                            ),
                            SizedBox(height: 20.h),
                            if (profileData.certificate != null)
                              Container(
                                margin:
                                EdgeInsets.symmetric(horizontal: 20.w),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(20.r),
                                  child: Image.network(
                                    profileData.certificate!,
                                    fit: BoxFit.cover,
                                    width: 360.w,
                                    height: 250.h,
                                    errorBuilder:
                                        (context, error, stackTrace) =>
                                        Column(
                                          mainAxisAlignment:
                                          MainAxisAlignment.center,
                                          children: [
                                            Icon(
                                              Icons.upload_sharp,
                                              color: Color(0xFF008080),
                                              size: 30.sp,
                                            ),
                                            SizedBox(height: 10.h),
                                            Text("Failed to load certificate"),
                                          ],
                                        ),
                                  ),
                                ),
                              )
                            else
                              Center(
                                child: Text(
                                  "No certificate uploaded",
                                  style: TextStyle(
                                    color: Colors.grey,
                                    fontSize: 16.sp,
                                  ),
                                ),
                              ),
                            SizedBox(height: 40.h),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                // Header Title
                Positioned(
                  top: 30.h,
                  left: 20.w,
                  right: 20.w,
                  child: Text(
                    "Profile",
                    style: GoogleFonts.roboto(
                      fontSize: 20.sp,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                ),
                // Profile Picture
                Positioned(
                  left: 0,
                  right: 0,
                  top: 110.h,
                  child: Stack(
                    clipBehavior: Clip.none,
                    children: [
                      Center(
                        child: ClipOval(
                          child: profileData.profilePic != null
                              ? Image.network(
                            profileData.profilePic!,
                            height: 182.w,
                            width: 182.w,
                            fit: BoxFit.cover,
                            errorBuilder:
                                (context, error, stackTrace) =>
                                Image.network(
                                  "https://upload.wikimedia.org/wikipedia/commons/8/89/Portrait_Placeholder.png",
                                  height: 182.w,
                                  width: 182.w,
                                  fit: BoxFit.cover,
                                ),
                          )
                              : Image.network(
                            "https://upload.wikimedia.org/wikipedia/commons/8/89/Portrait_Placeholder.png",
                            height: 182.w,
                            width: 182.w,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      Positioned(
                        right: 100.w,
                        bottom: -5,
                        child: InkWell(
                          onTap: () {
                            Navigator.push(
                              context,
                              CupertinoPageRoute(
                                builder: (context) =>
                                    ProfileCompletionWidget(true),
                              ),
                            );
                          },
                          child: Container(
                            width: 50.w,
                            height: 50.h,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Color(0xff008080),
                            ),
                            child: Icon(
                              Icons.edit,
                              color: Colors.white,
                              size: 24.sp,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

              ],
            ),
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, stack) {
          log(stack.toString());
          log(error.toString());
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('Error: $error'),
                ElevatedButton(
                  onPressed: () => ref.refresh(userProfileController),
                  child: const Text('Retry'),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
  // Helper widget to avoid repeating code
  Widget _buildInfoSection({
    required String title,
    required String value,
    required ThemeMode themeMode,
  }) {
    return Container(
      margin: EdgeInsets.only(left: 20.w, top: 15.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: GoogleFonts.roboto(
              fontSize: 20.sp,
              fontWeight: FontWeight.w600,
              color:
              themeMode == ThemeMode.dark ? Color(0xFF1B1B1B) : Colors.white,
            ),
          ),
          SizedBox(height: 10.h),
          Text(
            value,
            style: GoogleFonts.roboto(
              fontSize: 15.sp,
              fontWeight: FontWeight.w600,
              color: themeMode == ThemeMode.dark
                  ? Color(0xff666666)
                  : Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}